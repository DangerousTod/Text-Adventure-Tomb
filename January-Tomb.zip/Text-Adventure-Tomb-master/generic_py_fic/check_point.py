def check_point():

  file = open('inventory.txt','r')
  inventory = file.read()
  if '<first req. item>' in inventory:
    file.close()
    file = open('inventory.txt','r')
    inventory2 = file.read()

    if '<second req. item>' in inventory2:
      file.close()

      file = open('inventory.txt','a')
      file.write('<pay load>\n')
      file.close()

      file = open('inventory.txt','r')
      items = file.readlines()

      line_write_file = open('inventory.txt','w')
      for item in items:
        if item != ('<first req. item>\n'):
          line_write_file.write(item)
          continue
        continue
      file.close()
      line_write_file.close()

      file = open('inventory.txt','r')
      second_read_lines = file.readlines()

      second_line_write_file = open('inventory.txt','w')

      for second_read_line in second_read_lines:
        if second_read_line != ('<second req. item>\n'):
          second_line_write_file.write(second_read_line)
          continue
        continue
        
      file.close()
      second_line_write_file.close()
  


def log_in():
  file = open('player_card.txt','r')
  contents = file.read()
  print(contents)
  player_name = input("Choose the player to resume from this list\nChoose player: \n")
  if player_name.lower() in contents:
    file.close()

    file = open('' + player_name + '_holding.txt','r')
    my_weapons = file.readlines()
    hold = open('holding.txt','w')
    for my_weapon in my_weapons:
      hold.write(my_weapon)
      continue
    file.close()
    hold.close()

    file = open('' + player_name + '_wearing.txt','r')
    my_clothings = file.readlines()
    armor = open('wearing.txt','w')
    for my_clothing in my_clothings:
      armor.write(my_clothing)
      continue
    file.close()
    armor.close()

    file = open('' + player_name + '_inventory.txt','r')
    my_items = file.readlines()
    inventory = open('inventory.txt','w+')
    for my_item in my_items:
      inventory.write(my_item)
      continue
    file.close()
    inventory.close()
    run_game()

  else:
    file.close()
    print("Player not found.\n")
    title_screen()  


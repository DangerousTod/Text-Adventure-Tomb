
def log_out():
#create name entry for player

  file = open('player_card.txt','a')
  file.write('' + str(my_player.name) + '\n')
  file.close
#transfer holding to player file

  file = open('' + my_player.name + '_holding.txt','w+')
  file.close()
  file = open('holding.txt','r')
  my_weapons = file.readlines()
  hold = open('' + my_player.name + '_holding.txt','w')
  for my_weapon in my_weapons:
    hold.write(my_weapon)
    continue
  file.close()
  hold.close()
#transfer wearing to player file

  file = open('' + my_player.name + '_wearing.txt','w+')
  file.close()
  file = open('wearing.txt','r')
  my_clothings = file.readlines()
  armor = open('' + my_player.name + '_wearing.txt','w')
  for my_clothing in my_clothings:
    armor.write(my_clothing)
    continue
  file.close()
  armor.close()
#transfer inventory to player file

  file = open('' + my_player.name + '_inventory.txt','w+')
  file.close()
  file = open('inventory.txt','r')
  my_items = file.readlines()
  inventory = open('' + my_player.name + '_inventory.txt','w+')
  for my_item in my_items:
    inventory.write(my_item)
    continue
  file.close()
  inventory.close()
  sys.exit()

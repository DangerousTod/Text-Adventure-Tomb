import textwrap
import time
import random
import math
import csv
##############################################################################
#  SWORD + FORTUNE + GOLD = YOU WIN PLAY THE NEXT MODULE SOON!               #
##############################################################################
#
ZONEMAP = []
ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
UP = 'up'
DOWN = 'down'
EXIT = 'north'
DEATH = 'death'
ESCAPE = 'escape'
NO_MOVE = 'no_move'
ITEM = 'item'


solved_places = {'Great_Hall':False, 'Long_Hall':False, 'Trophy_Room':False, 'Trophy_Room_Vampire':False, 'Kitchen':False, 'You_Killed_The_Vampire':False, 'You_Killed_The_Zombie':False }

zonemap = {
  'Great_Hall': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'A flurry of bats suddenly flaps through the doorway, their screeching barely \n' +
'audible as they careen past your head. They flap past you into the rooms \n' +
'and halls beyond. The room from which they came seems barren at first glance.\n\n' +
'An old clock stands at the north side of the room between two cobweb covered \n' +
'bookshelves. It clicks loudly. Its winding is too slow and the gears rattle \n' +
'with every passing tick.\n\n' +
'To the East is a Door\n\n' +
'High above the bookshelf is a large round window. It is cloudy with dirt and \n' +
'age. Another window just like it is high up on the east wall just below the \n' +
'carved wooden rafters. On the south wall are dozens of oil paintings, normal \n' +
'haunted house painting of ancestors of people who are long since gone away \n' +
'posing like royalty wearing kilts beside a fire as dogs roll about at foot. Yet \n' +
'behind you there is no window. You turn and look and sure enough a thick black \n' +
'curtain covers nearly the entire wall. It is only pulled back enough for the \n' +
'door to swing inward.\n\n' +
'The clock rattles again. The poor thing almost seems to be in pain. Maybe you \n' +
'can fix it. The glass door has a handle.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine Bookshelf?\n2.) Check Behind The Curtain?\n3.) Open The Glass Door Of The Clock?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Trophy_Room',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'Bookshelf, Old Paintings, Clock, Curtain\n'
  },
  'Long_Hall': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You enter a long hall and your steps echo. Looking about, you\'re uncertain \n' + 
'why, but then a wall vanishes and reveals an enormous chamber. The wall was \n' +
'an illusion and whoever cast it must be nearby!\n\n'+
'To the North is a Door\n'+
'To the East is a Door\n\n'+
'You spin around looking in every direction quickly. It seems you are in the \n' +
'entrance room to this mansion where the curtains and clock were, the room full\n' +
'of cobwebs and books. The wall where the paintings hung is right in front of \n' +
'you, you are simply on the other side of it!\n\n' +
'A woman appears. There is a door to the north, back to the entrance or maybe \n' +
'you could flee back to the east, through the kitchen.\n',
	EXAMINATION: '\n\nChallenges:\n1.) Hear Your Fortune?\n2.) Escape This Haunted Mansion?\n3.) Run From The Fortune Teller?\n',

	SOLVED: False,
	NORTH: 'Great_Hall',
	SOUTH: '',
	EAST: 'Kitchen',#First: Zombie Fight
	WEST: '',
        UP: 'Dusty_Staircase',
        DOWN: '',
        ESCAPE: 'Exit',#Oh yes, you can run
	ITEM: 'Fortune Teller, Small Table, Coat Rack\n'
  },
  'Trophy_Room': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'Neither light nor darkvision can penetrate the gloom in this chamber. An \n' + 
'unnatural shade fills it, and the room\'s farthest reaches are barely \n' +
'visible. Near the room\'s center, you can just barely perceive a lump about \n' +
'the size of a human lying on the floor.\n\n'+
'To the South is a Door\n'+
'To the West is a Door\n\n' +
'You creep slowly into the gloom. The carpet crunches under your feet. Even a \n'+
'flashlight with full batteries cannot help you make out the fingers of you own\n'+
'hand before your face. You bump into a statue and hear the quiet tinkling of \n'+
'bells, but from where?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the Statue?\n2.) Investigate the Lump?\n3.) Look more closely at the Coffin?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: 'Kitchen',
	EAST: '',
	WEST: 'Great_Hall',#Pretty smart start for an adventurer
        UP: '',
        DOWN: '',
	ITEM: 'Carpet, Statue, Animal Head Trophies, Coffin\n'
  },
  'Trophy_Room_Vampire': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'Neither light nor darkvision can penetrate the gloom in this chamber. An \n' + 
'unnatural shade fills it, and the room\'s farthest reaches are barely \n' +
'visible.\n\n'+
'To the South is a Door\n'+
'To the East is a Stairway, how curious\n\n' +
#'To the West is a Door\n\n' +
'You creep slowly into the gloom. The carpet crunches softly. \n' +
'You hear terrifying laughter, but from from where?\n\n',
	EXAMINATION: '\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: 'Kitchen',
	EAST: 'Stairway',
	WEST: '',#'Great_Hall',#Pretty smart start for an adventurer
        UP: '',
        DOWN: '',
	ITEM: 'Carpet, Statue, Animal Head Trophies, Coffin\n'
  },
  'Kitchen': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'A crack in the ceiling above the middle of the north wall allows a trickle \n' +
'of water to flow down to the floor. The water pools near the base of the \n' +
'wall, and a rivulet runs along the wall an out into the hall. The water \n' +
'smells fresh. Through grimy windows you see a clue as to why such terrible \n' +
'things have happened here: behind this terrible house is a tiny graveyard \n' +
'buried in moss and weeds.\n\n' +
'To the North is a Door\n' +

'To the West is a Door\n\n' +
'A greybearded man emerges from the gardener\'s shed. He lets the door slam \n' +
'shut with a loud metal bang! Just then you notice a beautiful wooden box on \n' +
'top of an old table. Beside the box is a huge tarantula spider!\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Hide From The Gardener?\n2.) Open Wooden Box?\n3.) Squish The Spider?\n',

	SOLVED: False,
	NORTH: 'Trophy_Room_Vampire',#Did you forget about the Vampire???
	SOUTH: '',
	EAST: '',
	WEST: 'Long_Hall',
        UP: '',
        DOWN: '',
  #      ESCAPE: 'Exit',
	ITEM: 'Table, Spider\n'
  },
  'Death': {
        ZONENAME: 'start',
        DESCRIPTION:
'What a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0            0  0000  0       0          00         0  00000  0        00000|0\n'+
'000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n'+
'0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n'+
'00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n'+
'0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n'+
'00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n'+
'0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n',
        EXAMINATION: '\n\n\n\nYou go on ahead, we will wait right here...\n',
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: ''
  },
  'Exit': {
       ZONENAME: 'start',
       DESCRIPTION:
'You bolt from the door of the mansion. Jump on your bike and start pumping \n' +
'the pedals. You feel incredible. Somehow terrified and thrilled at the same \n' +
'time. You have a prickly feeling you will be back.\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0            0  0000  0       0          00         0  00000  0        00000|0\n'+
'000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n'+
'0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n'+
'00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n'+
'0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n'+
'00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n'+
'0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n',
        EXAMINATION: '\n\n\n\nYou go on ahead, we will wait right here...\n',
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: ''
  },
  'Study': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'The door in the cloak room was very hard to detect. It was too small and \n' +
'square, not at all like a door should be. Now you are in the study. This \n' +
'room was certainly a secret known only to who ever it was who lived here. \n' +
'Should there be a way to figure out who lived in a house after many years \n' +
'have passed? Maybe there is.\n\n'+
'To the East is a Door\n\n' +
'In the study is another world, a still quiet world. A desk dominates the \n' +
'small room and open on the desk is a monsterous book. It is at least three \n' +
'feet thick and probably five feet tall if you had someone to help you stand \n' +
'it up. Drawn on its pages are fantastic creatures and strange words. To your \n' +
'amazement there are three more books standing side by side along the wall.\n' +
'All three books are just an incredibly large!\n\n',
#'To the  is a Door\n\n' +
#'?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Read from the book?\n2.) Check in the desk drawers?\n3.) Open one of the other books?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Cloak_Room',
	WEST: 'Hidden_Passage',
        UP: '',
        DOWN: '',
	ITEM: 'Desk, Giant Books.\n',
  },
 'Quiet_Hall': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the upstairs hallway. The walls are paneled with dark stained \n' +
'wood. The ceiling is too thick with cobwebs to be seen. The cobwebs are the \n' +
'really sticky kind that gather together after months and months-perhaps \n' +
'years. The length of the hallway is north to south. The carpet is both red \n' +
'and gold, the two colors being twisted together in a labyrinth.\n\n'+
'To the North is a Stairway\n'+
'To the South is a Door\n'+
'To the East is a Door\n'+
'To the West is a Door\n\n' +
'A natural inclination to be stealthy overtakes you as you creep by the doors \n' +
'in the hall. Along the way, one on the left, and then one on the right, are \n' +
'small potted plants. The plant have died long ago and a faint white mold \n' +
'grew on the leaves before it too died.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Wait and listen?\n2.) Look more closely at the carpet?\n3.) Rescue a plant?\n',

	SOLVED: False,
	NORTH: 'Hidden_Stairway',
	SOUTH: 'Cloak_Room',
	EAST: 'Big_Bedroom',
	WEST: 'Small_Bedroom',
        UP: '',
        DOWN: '',
	ITEM: 'Potted Plants\n',
  },
  'Big_Bedroom': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'You are in the big bedroom. It is certainly a large room. It is in disarray. \n' +
'Many household items are strewn about the southern side of the room around a \n' +
'mattress which stands on edge. Behind the mattress is a large mirror. The \n' +
'mirror is so large in fact that it protrudes from either end of the leaning \n' +
'mattress. The rails and posts of the bed are stacked along side the mattress. \n' +
'A very large window looks out on the property. From what you can see, \n' +
'mostly trees it is hard to say which part of the property this window is \n' +
'above.\n\n'+
'To the West is a Door\n\n',
#'To the  is a Door\n\n' +
#'?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Look out the window?\n2.) Search the household odds and ends?\n3.) Move the mattress?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: 'Quiet_Hall',
        UP: '',
        DOWN: '',
	ITEM: 'Large Mirror, Mattress, Bed Posts and Rails\n',
  },
 'Small_Bedroom': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the small bedroom. A bookcase stands beside one wall and large \n' +
'dressing cabinets stands against the opposite. Directly across from the door \n' +
'is a large bed which nearly fills the room. The floor is spongy. You can \n' +
'see that it is a wooden floor, underneath it must be starting to rot or it \n' +
'is broken somehow.\n\n'+
'To the East is a Door\n\n',
#'To the  is a Door\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the spongy floor?\n2.) Look at the bookcase?\n3.) Jump on the bed?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Quiet_Hall',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'Bookcase, Cabinet, Bed.\n',
  },
  'Stairway': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'You are on the Stairway. It connects the upper hallway to the trophy room \n' +
'below. The stairway is narrow with small window which only glow of the \n' +
'daylight outside, you cannot see through. At a ninety degree turn in the \n' +
'stairway is the most ugly and gothic picture of a face. It might be \n' +
'laughing, it might be crying, it might be angry-there is no way to tell it \n' +
'is all three at the same time somehow.\n\n'+
'To the South is a Door\n'+
'To the West is a Door\n\n',
#'?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the painting?\n2.) Turn around quick in case someone is following you?\n3.) Remind yourself there is no such thing as ghosts and goblins?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: 'Quiet_Hall',
	EAST: '',
	WEST: 'Trophy_Room_Vampire',
        UP: '',
        DOWN: '',
	ITEM: 'Hideous Painting\n',
  },
 'Cloak_Room': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Cloak Room. What a very odd little room. One one side hang \n' +
'clothes of every size, children and adults and every size in between. All \n' +
'of the garments are stiff with startch and look like wool. A few items are \n' +
'boring old wool coats and socks. Most of the items are colorful and are \n' +
'embroidered and bedazzled with tiny beads.\n' +
'On the other side of the tiny room however is tiny chair and a stone water \n' +
'fountain. The large bowl and drain give away the nature of the device. \n' +
'But how strange, why have a bird bath inside?\n\n'+
'To the North is a Door\n\n'+
#'To the West is a Door\n\n'+
'This room smells faintly of pipe tobacco. The smell is very faint yet has \n' +
'hints of cherry and apple with the special firey note that pipe \n' +
'tobacco leaves behind. Also a small cabinet is above the clothing rack.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Dig through the clothes?\n2.) Open the cabinet?\n3.) Sit on the tiny chair?\n',

	SOLVED: False,
	NORTH: 'Quiet_Hall',
	SOUTH: '',
	EAST: '',
	WEST: 'Study',
        UP: '',
        DOWN: '',
	ITEM: 'Tiny Chair, Ceramic Water Fountain, Racks of Clothes, Cabinet.\n',
  },
  'Hidden_Stairway': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'You are on the Stairway. It connects the upper hallway to the trophy room \n' +
'below. The stairway is narrow with small window which only glow of the \n' +
'daylight outside, you cannot see through. At a ninety degree turn in the \n' +
'stairway is the most ugly and gothic picture of a face. It might be \n' +
'laughing, it might be crying, it might be angry-there is no way to tell it \n' +
'is all three at the same time somehow.\n\n'+
'To the South is a Door\n\n'+
'Oh, my! There WAS a door here! You are sure of it! How else could you have \n' +
'gotten into the upstairs hallway? Why is the painting clearly frowning now? \n' +
'Oh no! You are trapped! \n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the painting?\n2.) Turn around quick in case someone is following you?\n3.) Remind yourself there is no such thing as ghosts and goblins?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Quiet_Hall',
	EAST: '',
	WEST: '',#'Trophy_Room_Vampire',
        UP: '',
        DOWN: '',
	ITEM: 'Hideous Painting\n',
  },
###############################tomb#zonename#tomb############################################################
  'Darkened_Stairway': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
										
	DESCRIPTION: 
'You are on the Darkened Stairway. The steps double back every hundred feet \n' +
'from one small landing to the next. As you descend the walls turn from brick \n' +
'to mud, then clay, and then finally hard gray rock. It could be granite. It \n' +
'is rough like volcanic rock. At the bottom of the stairway is a large stone \n' +
'with black, half-moon shaped hole.\n\n' +
'A Chute leads Down from Here\n\n' +
'The half-moon is a deeper black than your torch can penetrate. There are \n' +
'handholds. You climb up and peer down into the empty darkness. The light of \n' +
'your electric torch. Above you is a loud, CLANG!!! \n' +
'The Chute seems to be a slide...\n\n', # +

	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: 'Study',
        DOWN: 'Bottom_of_Chute',
	ITEM: '\n'
  },
  'Bottom_of_Chute': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are at the bottom of a chute. Alone and trapped in total darkeness...\n' +
'just then your electric torch sizzles and lights up the room.\n' +
'You cannot reach the bottom of the chute. It is too high for you to jump up \n' +
'and grab. You cannot find even something you can drag to the chute to \n' +
'stand on.\n\n' +
'To the North is a Door...\n' +
'However the door is terribly ugly and solidly locked.\n\n' +
'The giant green face on the door suddenly comes alive! Tell me are you still \n' +
'having fun? I hope so, I hope I am not too \n' +
'scary because I have a riddle for you...\n\n' +
'What sings, has one arm and turns round and round and round?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Do you know the answer?\n2.) Do you need a hint?\n3.) Would you like a new riddle?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'A Horrible Laughing Clown Faced Door\n'
  },
  'Water_Fountain': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You stand beside a water fountain. Water bubbles from a spout in the exact \n' +
'center of three crossing hallways to spill over fantastic animals, weird \n' +
'flowers and strange vegetables. Tiny boys carved of stone hide in the flora \n' +
'and fauna where the water falls playfully on them.\n\n' +
'To the North is a Hallway\n' +
'To the South is a Hallway\n' +
'A sloping Hallway is Down from Here\n\n' +
#'\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Investigate the Carvings?\n2.) Try the Fourth Key?\n3.) Read the Note?\n',

	SOLVED: False,
	NORTH: 'Faded_Tapestries',#Where the Griffin hides
	SOUTH: 'Library',#Don't anger the Gnome
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: 'Room_of_Faces',#The haunt of the Grimlock
	ITEM: '\n'
  },
  'Library': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the underground library. Beautiful pillars create a central forum \n'+
'in this large open room. A strange flickering light falls from the tiled \n' +
'ceiling. Beyond this light, somehow above the ceiling itself is a picture of \n' +
'shadows changing together in an endless story of sights to see.\n\n' +
'To the North is a Door\n'
'To the South is a Door\n\n' +
'Around the pillars arranged along the walls are large couches and chairs \n' +
'with thick cushions. Behind the chairs and couches are many long shelves of \n' +
'books. Many books are very old but a few are new. Something catches your eye \n' +
'it is another note from the mysterious Einar. No, wait, there are at least \n' +
'three notes...or is it one note ripped into three pieces?\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Take the Red Note?\n2.) Take the Blue Note?\n3.) Take the Green Note?\n',

	SOLVED: False,
	NORTH: 'Water_Fountain',
	SOUTH: 'Bottom_of_Chute',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'Desks, Chairs, Tall White Pillars, Flickering Oil Lamps, Book Shelves.\n'
  },
  'Room_of_Faces': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You balance on the stone aisle between the two channels of water following \n' +
'them down into a large dome shaped room. Across the central pool of water is \n' +
'a large Green Door.\n\n' +
'A hallway leads upward.\n\n' +
'Within the dome shaped room are four silent stone faces each looking down. \n' +
'Their heads are bowed and their eyes are closed. They do not move, they do \n' +
'now speak, they are simply looking downward. The water from the water \n' +
'fountain flows into their big open mouths.\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Turn the Star?\n2.) Try the Fourth Key?\n3.) Read the Note?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: 'Water_Fountain',
        DOWN: '',
	ITEM: '\n'
  },
  'Faded_Tapestries': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'This is the Hall of Tapestries. Perhaps a king lived here long long ago...\n' +
'Anything can happen in New Jersey, right?\n\n' +
'To the South is a Hallway\n' +
'To the East is Large Green Door\n\n' +
'You are certain you can hear voices nearby, voices echoing from above the \n' +
'house perhaps? You slid quite far in the chute, and that slide was only \n' +
'after descending many flights of steps, you might guess you could even be \n' + 'underneath of the wooded lot at the back of the property. \n' +
'Oh, no it seems the door to the East is locked!\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the Tapestries?\n2.) Search for and Escape Route?\n3.) Try the Green Key?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Water_Fountain',
	EAST: '',#'Singing_Crystals',To Be Locked
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Singing_Crystals': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'Around you are thousands of tiny singing crystals. \n\n' +
'To the South is a Large Green Door\n' +
'To the West is a Large Yellow Door\n\n' +
'The cystals swirl through the air in magical musical patterns playfuly softly \n' +
'glittering and humming. Before your very eyes you see strange symbols form in \n' +
'in the patterns of the singing crystals. The symbols look familiar, almost \n' +
'like words, familiar words. Could these symbols be simillar to the strange \n' +
'writing on the notes from the Library?\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Use the First Clue?\n2.) Use the Second Clue?\n3.) Use the Third Clue?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Inner_Chamber',
	EAST: '',
	WEST: 'Faded_Tapestries',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Stairway_and_Candles': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You have seen some odd things in the past few hours, this is downright mond \n' +
'boggling. In front of you is a stairway lit by hundreds of candles leading \n' +
'up to the stone wall at the southern end of this subterreanean maze.\n\n' +
'To the North is a Hallway\n\n' +
'The candles do not seem to run out of fuel. Their light is warm and constant. \n' +
'The wall, unlike the others walls where the rock is either natural or filled \n' +
'in with large stone blocks is a broad flat void of stone with no indication \n' +
'as to why candles and a stairway are here.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Light a Candle?\n2.) Blow a Candle Out?\n3.) Read the Note?\n',

	SOLVED: False,
	NORTH: 'Inner_Chamber',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Inner_Chamber': {
	ZONENAME: 'tomb',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Inner Chamber. Tiny stones float in the air circling a large \n' +
'central pedestal. Around the pedestal on the ground are thousands of \n' +
'brilliant gemstones poking through the purplish rock floor. Each gemstone is \n' +
'perfectly carved and polished.\n\n' +
'To the North is a Large Green Door\n' +
'To the South is a Large Black Door\n\n' +
'On the pedestal is a large black disc with with three golden stars carved on \n' +
'its face. The stars has many many points and share the same central star. The\n' +
'stars even look a bit like gears! And each star has gleaming golden arrow! If\n' +
'you could align the arrows maybe you could escape from this dungeon.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Turn the Outer Star?\n2.) turn the Middle Star?\n3.) Turn the Inner Star?\n',

	SOLVED: False,
	NORTH: 'Singing_Crystals',
	SOUTH: 'Stairway_and_Candles',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'Golden Wheel Gears, Floating Pebbles, Candles\n'
  },
#############################################################################################################
  'Graveyard': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Graveyard.\n\n' +
'To the North is the Gardeners Shed\n' +
'To the West is a Patch of Weeds\n\n' +
'Hopefully you are only visiting.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Read Tombstone?\n2.) Watch for the Gardener?\n3.) Examine Pile of Stones?\n',


	SOLVED: False,
	NORTH: 'Shed_Door',
	SOUTH: '',
	EAST: '',
	WEST: 'Weeds',
        UP: '',
        DOWN: '',
	ITEM: 'Tombstones, Large Bushes, Broken Tombstones, Fallen Tree\n'
  },
  'Gardeners_Shed': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Gardeners Shed.\n' +
'To the West is a Door\n\n' +
'Junk is everywhere in a vague organization of things on metal shelves\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine Broken Lawnmower?\n2.) Search Workbench?\n3.) Examine Gears?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: 'Shed_Door',
        UP: '',
        DOWN: '',
	ITEM: 'Long Metal Racks, Broken Lawnmower, Can of Gasoline, Pruning Shears, Lawnmower Parts, Gears, Chains, Hammers, Wrenches, Coffee Machine\n'
  },
  'Kitchen_Door': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are at the Kitchen Door of the Old Mansion.\n\n' +
'To the East is a Patch of Weeds\n' +
'To the West is the Kitchen\n\n' +
'You can wait, nothing will be for dinner.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine Leaking Hose?\n2.) Try to Fix Broken Bench?\n3.) Examine Flower Pots?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Weeds',
	WEST: 'Kitchen',
        UP: '',
        DOWN: '',
	ITEM: 'Flower Baskets, Broken Benches, Leaking Hose\n'
  },
  'Shed_Door': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are the Door of the Gardeners Shed.\n\n' +
'To the South is a Graveyard\n' +
'To the East is the Door of the Gardeners Shed\n' +
'To the West is a Vegetable Patch\n\n' +
'The Gardener comes and goes from here often.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Catch a Grasshopper?\n2.) Sneak Around the Gardeners Shed?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Graveyard',
	EAST: 'Gardeners_Shed',
	WEST: 'Vegetable_Patch',
        UP: '',
        DOWN: '',
	ITEM: 'Thick weeds, Grasshopper Bugs, Small Rocks, Dried Mud\n'
  },
  'Weeds': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in a weed patch at the back of the Mansion.\n\n' +
'To the North is a Vegetable Patch\n' +
'To the East is a Graveyard\n' +
'To the West is the Mansion\n\n' +
'Instead of mowing down the weeds the Gardener simply clears a patch between \n' +
'the Shed, the Graveyard and the Mansion.\n\n',
#	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Vegetable_Patch',
	SOUTH: '',
	EAST: 'Graveyard',
	WEST: 'Kitchen_Door',
        UP: '',
        DOWN: '',
	ITEM: 'Thick Weeds, Mosquitos\n'
  },
  'Vegetable_Patch': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are at the Edge of a small Vegetable Patch.\n\n' +
'To the South is a Weed Patch\n' +
'To the East is the Gardeners Shed\n\n' +
'Various peppers grow in the Vegetable Patch along side tomatoes, a string of \n' +
'carrots, a few marigolds and five large sunflowers.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Gather Sunflower Seeds?\n2.) Squish Tomatoes?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Weeds',
	EAST: 'Shed_Door',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: 'Peppers, Tomatoes, Carrots, Marigolds, Sunflowers\n'
  },
 'Paneled_Hall': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in a hallway above the fortune teller\'s shop in the \n' +
'old mansion. Dark stained wooden panels don\'t hint the someone wealty \n' +
'lived here. Now thick cobwebs fill the corners of the hall, and wisps of \n'+
'webbing hang from the ceiling and waver in a wind you can barely feel. \n'+
'One corner of the ceiling has a particularly large clot of webbing within \n'+
'which a spider\'s nest hangs.\n\n'+
'To the North is a Door\n'+
'To the South is a Door\n'+
'To the East is a Door\n'+
'To the West is a Door\n\n' +
'Here the carpet is thick and very dusty.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Conservatory',
	SOUTH: 'Dusty_Staircase',
	EAST: 'Childrens_Bedroom',
	WEST: 'Guest_Bedroom',
        UP: '',
        DOWN: '',
	ITEM: '\n',
  },
  'Childrens_Bedroom': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'You are in the Children\'s bedroom.\n' +
'A cluster of low crates surrounds a barrel in the center of what is \n' +
'clearly a child\'s bedroom. Atop the barrel lies a stack of dried cakes \n' +
'and two stacks of silly playing cards, one face up. Meanwhile, atop each \n' +
'crate rests a fan of five face-down playing cards. A thin layer of dust \n'+
'covers everything. Clearly for some reason, someone meant to return to \n' +
'their game of cards.\n\n'+
'To the West is a Door\n\n'+
#'To the  is a Door\n\n' +
'Memories of the children who played here are so strong, so loud.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Look at the hand of cards?\n2.) Open the painted barrel?\n3.) Eat on of the cakes?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: 'Paneled_Hall',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 'Guest_Bedroom': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Guest Bedroom \n' +
'This large, rectangular bedroom has coordinating wooden and glass \n' +
'furniture.  The floor is carpeted and the walls are textured and \n' +
'painted.  Light is provided by wall lamps.  The room is done in murky \n' +
'colors and overall looks a bit old-fashioned.\n\n'+
'To the East is a Door\n\n'+
#'To the  is a Door\n\n',
'What lovely quilts and lace shams all ashamble. Among the things tossed\n' + 
'about are a dozens of old magazines and a corkbord full of clippings.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine the cork board?\n2.) Look through the magazines?\n3.) Try one of the lamps?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Paneled_Hall',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n',
  },
  'Dusty_Staircase': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS###############################################
	DESCRIPTION: 
'You are on the Dusty Staircase.\n' +
'\n\n'+
'You can go Up the Stairs\n'+
'You can go Down the Stairs\n\n'+
'The fortune teller might not like you sneaking around.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',
 
	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: 'Paneled_Hall',
        DOWN: 'Long_Hall',
	ITEM: '\n',
  },
 'Conservatory': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the conservatory.\n' +
'This room is cold as a tomb and the decorater really ran with it. \n'+
'Miniature stone sarcophagi stand in five rows of three, each \n' +
'carved with the visage of a warrior lying in state on the mantle of \n' +
'a beautiful stone hearth. In their center beneath a tin coat of arms\n' +
'one sarcophagus stands taller than the rest. Held up by six squat \n' +
'pillars, its stone bears the carving of a beautiful woman who seems \n' +
'more asleep than dead. The carving of the warriors is skillful but \n' +
'seems perfunctory compared to the love a sculptor must have lavished \n' +
'upon the lifelike carving of the woman.\n\n'+
'To the South is a Door\n\n'+
#'To the West is a Door\n\n'+
'Relics of another time are here. Swords line the walls and couches \n' +
'circle a large phonograph. A golden chain hangs from the phonograph. \n' +
'Its amplifying horn is brass, dimmed with age now. Finally a \n' +
'a chandalier draped in a cotton sheet sits on the floor in the center \n' +
'of the room.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Pull the chain?\n2.) Investigate the sarcophagi?\n3.) Look at the weapon collection?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Paneled_Hall',
	EAST: 'Hidden_Passage',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '.\n',
  },
 'Hidden_Passage': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are under the floor of the mansion in a hidden passage you found above the \n' +
'either the Great Hall or the Trophy Room.\n' +
'\n\n'+
'To the East is a Tiny Door\n\n'+
'To the West is a Tiny Door\n\n'+
'The narrow tunnel is also very low making you crawl. \n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Study',
	WEST: 'Conservatory',
        UP: '',
        DOWN: '',
	ITEM: '.\n',
  },
}


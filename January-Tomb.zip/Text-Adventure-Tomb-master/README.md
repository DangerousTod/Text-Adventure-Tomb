# Text-Adventure-Tomb
Python Text Adventure with CRUD
Python3 and Linux

from Text-Adventure-Tomb in terminal run command:
python3 tomb_main.py

Notice Also: One word names are required at this point

New File Structure: It is still simple makes new players, as well as 
saved quit locations a snap. The structure is also of the folded 
type we are using. Room content files as well as Player inventory 
files are copied into a directory created for the new player.
As for saving a quit location...lets just say I got it to work.
*******************NOTICE*******************NOTICE***********************
IF YOU DO NOT SELECT YES WHEN PROMPTED TO SAVE YOUR PLAYER YOUR ENTIRE 
PLAYER RECORD AND DIRECTORY WILL NOT BE SAVED, THAT DIRECTORY WILL BE 
DELETED!! THERE IS A PROMPT TO BE CERTAIN THAT THIS CHOICE IS 
INTENTIONAL. THERE IS NO RECOVERY OR UNDO WHEN USING THE TERMINAL...
though I have some GUI plans...
*******************NOTICE*******************NOTICE************************
Here is the folder structure:
Text-Adventure-Tomb-master\
		\Items
			\__pycache__
			basic_inventory.txt
			holding.txt
			__init__.py
			inventory.txt
			wearing.txt
		\List
			\__pycache__
			basic_inventory.txt
			clothing.txt
			__init__.py
			master-room-content.txt
			player_card.txt
			room-master.txt
			treasure.txt
			treasuryList.txt
			weaponOrTool.txt
		\Players 
			\__pycache__
			__init__.py
			\player_name
				collection of txt files
		\__pycache__
		\Rooms
			\__pycache__
			txt files of rooms in zonemap
	__init__.py
	masterList.py
	README.md
	tomb_main.py
	zonemap.py



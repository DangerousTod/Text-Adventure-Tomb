#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 17:59:58 2020

@author: jengwall
"""

import first_module
import alt_first_module
import alt_second_module

#first_module.title_screen()
#alt_first_module.combat_switch()
#alt_second_module.get_backpack_contents()


from Items import *
from Players import *
from Lists import *
from Rooms import *

#print("Second Module's Name: {}".format(__name__))
import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import time
from time import sleep
import math
import csv
import functools

#import textwrap
#import time
#import random
#import math
#import csv
##############################################################################
#  SWORD + FORTUNE + GOLD = YOU WIN PLAY THE NEXT MODULE SOON!               #
##############################################################################
#
ZONEMAP = []
ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
UP = 'up'
DOWN = 'down'
PRICES = 'prices'
EXIT = 'north'
DEATH = 'death'
ESCAPE = 'escape'
NO_MOVE = 'no_move'
ITEM = 'item'


solved_places = {'':False, '':False }

zonemap = {
  'xxxxxxxxx': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'Pinklemire Street.\n.\n'+

'\nTo the North is the Blacksmith\n'+
'To the South is the Message Post\n'+
'To the East is the Leather Shop\n'+
'To the West is the Pub\n'+
'Check out these low low prices\n'+
'Check Prices: Yes or No\n',

	SOLVED: False,
	NORTH: 'ccccccccc',
	SOUTH: 'vvvvvvvvv',
	EAST: 'bbbbbbbbb',
	WEST: 'nnnnnnnnn',
        UP: '',
        DOWN: '',
#        ITEM: '\n',
	PRICES:
'\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n'+
'\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n'+
'\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n'+
'\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n'+
'\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n',
  },
 'ccccccccc': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'Blacksmith.\n.\n'+

#'\nTo the North is a Door\n'+
'\nTo the South is a Door\n',
#'To the East is a Door\n',
#'To the West is a Door\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'xxxxxxxxx',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
#        ITEM: '\n',
  },
 'vvvvvvvvv': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'Message Post.\n.\n'+

'\nTo the North is a Door\n',
#'To the South is a Door\n'+
#'To the East is a Door\n'+
#'\nTo the West is a Door\n',

	SOLVED: False,
	NORTH: 'xxxxxxxxx',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
#        ITEM: '\n',
  },
 'bbbbbbbbb': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'Leather Shop.\n\n'+

#'\nTo the North is a Door\n'+
#'To the South is a Door\n'+
#'To the East is a Door\n'+
'\nTo the West is a Door\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: 'xxxxxxxxx',
        UP: '',
        DOWN: '',
#        ITEM: '\n',
  },
 'nnnnnnnnn': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'Pub.\n.)\n'+


#'\nTo the North is a Door\n'+
#'To the South is a Door\n'+
'\nTo the East is a Door\n',
#'To the West is a Door\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'xxxxxxxxx',
	WEST: '',
        UP: '',
        DOWN: '',
#        ITEM: '\n',
  },
}

first_module.title_screen()
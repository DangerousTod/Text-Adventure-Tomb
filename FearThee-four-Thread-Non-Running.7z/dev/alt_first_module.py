#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 18:46:08 2020

@author: jengwall
"""

import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import math
import csv
import functools

#######################################################################################

from time import sleep
from FearTheeZoneMap import *

from Items import *
from Players import *
from Lists import *
from Rooms import *

import first_module

import alt_second_module


#alt_second_module.alt_second_module.prompt()
#alt_second_module.main_game_loop()


#print("This will always run")

#def main():
#    print("First Alt Module's Main Method")
    
#if __name__=='__main__':
#    main()



def combat_switch():
  i = 0
  fights = player.player_get_fights()
  if fights < 3:
    ai = Ai(50, 5, 'Spider', dead=False)
    combat_handler(ai)
  elif fights < 8:
    ai = Ai(100, 10, 'Lizard Man', dead=False)
    combat_handler(ai)
  elif fights < 15:
    ai = Ai(200, 5, 'Grimlock', dead=False)
    combat_handler(ai)
  elif fights < 20:
    ai = Ai(400, 4, 'Azer', dead=False)
    combat_handler(ai)
  elif fights < 25:
    ai = Ai(600, 8, 'Shocker', dead=False)
    combat_handler(ai)
  elif fights < 30:
    ai = Ai(1000, 5, 'Ghoul', dead=False)
    combat_handler(ai)
  elif fights < 35:
    ai = Ai(1000, 15, 'Ogre', dead=False)
    combat_handler(ai)
  elif fights < 36:
    ai = Ai(2000, 20, 'Brass Dragon', dead=False)
    combat_handler(ai)
  if fights < 39:
    ai = Ai(500, 7, 'Purple Spider', dead=False)
    combat_handler(ai)
  elif fights < 48:
    ai = Ai(1000, 7, 'Mud Man', dead=False)
    combat_handler(ai)
  elif fights < 55:
    ai = Ai(1000, 20, 'Quickling', dead=False)
    combat_handler(ai)
  elif fights < 60:
    ai = Ai(1000, 15, 'Silver Beard', dead=False)
    combat_handler(ai)
  elif fights < 75:
    ai = Ai(3000, 18, 'Torturer', dead=False)
    combat_handler(ai)
  elif fights < 80:
    ai = Ai(1000, 50, 'Night Ghoul', dead=False)
    combat_handler(ai)
  elif fights < 95:
    ai = Ai(6000, 99, 'Lichess', dead=False)
    combat_handler(ai)
  elif fights == 100:
    ai = Ai(12000, 90, 'Green Dragon', dead=False)
    combat_handler(ai)
  else:
    ai = Ai(50, 5, 'Spider', dead=False)
    combat_handler(ai)

def combat_handler(ai):

  playername = player.name.lower()
  whereabouts = player.location.lower()
  battleground = whereabouts
  playerlocation = player.location.lower()
  if ai.dead == False:
    ai_fight(playername, ai, battleground, playerlocation)
  else:
    alt_second_module.prompt()



def player_move():
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:

    destination = zonemap[player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:

    destination = zonemap[player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:

    destination = zonemap[player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:

    destination = zonemap[player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:

    destination = zonemap[player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:

    destination = zonemap[player.location][DOWN]
    movement_handler(destination)
  elif destination in ['escape']:

    destination = zonemap[player.location][EXIT]
    game_over(destination)
  else:
    print("Where is that?\nYou stay where you are.\n")
  return player_move(playername)

ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
EXIT = 'escape'
DEATH = 'death'
ESCAPE = 'escape'


solved_places = {'Top Left Corner Room':False, 'Lower Left Room':False, 'Top Right Room':False, 'Lower Right Room':False, } # '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                }




def ai_intercept(combat_round, playername, ai, playerlocation):
  playerlocation = ai.location.lower()
  battleground = ai.location.lower()
  playerlocation = player.location.lower()
  print("" + str(ai.name.upper()) + " has found you!\n")
  print("The mad beast looks at you for a moment...\n")
  print( "" + str(ai.name.upper()) + " attacks!!!\n")
  combat_state = 1
  hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)



#######################################################################################################
#                                                                                                     #
#                                          combat loop basic                                          #
#######################################################################################################

def ai_fight(playername, ai, battleground, playerlocation):
  combat_round = 0
  combat_state = 1
  combat_round = combat_round
  while combat_state == 1:
    if battleground != playerlocation:
      if combat_state != 0:
        time.sleep(0.02)
        ai_intercept(combat_round, playername, ai, playerlocation)
      continue
    else:
      combat_state = 1
      hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
    
def hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation):
  combat_state = 1
  combat_round += 1
  playerattack = player.player_get_attack()
  playerweapon = player.player_get_weapon()
  player_dam_mesg = player.player_get_dam_mesg()
  while combat_state == 1:
    if player.health > 0:
      if ai.health > 0:
        ai.dead = False
        player_dam_math = ((int(playerattack)) * (random.randint(5, 10))) - ((int(ai.attack)) * (random.randint(3, 8)))
        ai_dam_math = ((int(ai.attack)) * (random.randint(4, 9))) - ((int(playerattack)) * (random.randint(3, 8)))
        if int(player_dam_math) < 0:
          print("You should run! The " + ai.name + " is too powerfull!")
          quarter = input("Do you want to fight or run: \n" )
          if quarter.lower() == ('fight'):
            input("Press Enter to Continue")
            player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
           
          elif quarter.lower() == ('run'):
            ai.dead = False
            combat_state = 1
            combat_round = 0
            i = 0
            player_move()
                   
          else:
            print("Unknown command")
            print("The battle continues.\n")
            player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
        else:
          if int(ai_dam_math) < 0:
            print("No damage.")
            ai.health -= abs(player_dam_math)
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
          else:
            player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
########################################################################################################
            ai.health -= abs(player_dam_math)
            if ai.health < 0:
              ai.dead = True
              combat_state -= 1
              combat_round = 0
              i = 0
              playerlocation = battleground
              playerlocation = player.location.lower()
              print('' + zonemap[player.location][DESCRIPTION] + ' ')
              with open('./Players/' + playername + '/' + playerlocation + '.txt','r') as file:
                things = file.read()
                print("Things here: \n")
                print(thing)
                with open('./Players/' + playername + '/victories.txt','a+') as file:
                  file.write('' + ai.name + '\n')
                print("Victory!\nThe " + ai.name + " has been defeated.")
              loot_state()
            elif player.health < 0:
              player.game_over = True
              combat_state -= 1
              combat_round = 0
              i = 0
              with open('./Players/' + playername + '/holding.txt','w') as file:
                file.write('silver skull')
              print('What a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|00 HA HA HA HA 00 THE UNDER KINGDOM LAUGHS 00 HA HA HA 0000|0000000000000000|0\n'+
'000000000000000000000000000000000000000000000000000000000000| 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000|00     000     00|000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000|000000000000000|0000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 000000000000000|000000000|00000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000 | | | | 00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
              sys.exit(0)
            else:
              mesg = random.randint(0,2)
              dam_mes = player_dam_mesg.pop(int(mesg))
              print("Points of damge you deal: " + str(player_dam_math) + "")
              print("When you " + str(dam_mes) + " with your " + playerweapon + ".")
########################################################################################################
              print("Your health: " + str(player.health) + "")
              print("" + ai.name + " health: " + str(ai.health) + "")
              print("Combat round: " + str(combat_round) + "")
              quarter = input("Do you want to fight or run: \n" )
              if quarter.lower() == ('fight'):
                input("Press Enter to Continue")
                hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
              elif quarter.lower() == ('run'):
                ai.dead = False
                combat_state = 1
                combat_round = 0
                i = 0
                player_move()                   
              else:
                print("Unknown command")
                print("The battle continues.\n")  
                hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
      else:
        ai.dead = True
        combat_state -= 1
        combat_round = 0
        i = 0
        playerlocation = battleground
        playerlocation = player.location.lower()
        print('' + zonemap[player.location][DESCRIPTION] + ' ')
        with open('./Players/' + playername + '/' + playerlocation + '.txt','r') as file:
          things = file.read()
          print(things)
        print("Victory!\nThe " + ai.name + " has been defeated.")
        with open('./Players/' + playername + '/victories.txt','a+') as file:
          file.write('' + ai.name + '\n')
        loot_state(playername)
    else:
      player.game_over = True
      combat_state -= 1
      combat_round = 0
      i = 0
      with open('./Players/' + playername + '/holding.txt','w') as file:
        file.write('silver skull')
      print('\nWhat a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|00 HA HA HA HA 00 THE UNDER KINGDOM LAUGHS 00 HA HA HA 0000|0000000000000000|0\n'+
'000000000000000000000000000000000000000000000000000000000000| 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000|00     000     00|000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000|000000000000000|0000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 000000000000000|000000000|00000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000 | | | | 00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
      sys.exit(0)
  return

def loot_state(playername):
  fights = player.player_get_fights()
  print("Victories: " + str(fights) + "!\n")

#########################################################################################################
  t_int = random.randint(0,12)
  reward = ['knife','mask','trident pin','onyx elephant','cloak','copper key','bread','faded picture','broken watch','beautiful ring','wand','carved jade dragon','shirt']
#########################################################################################################
  loot = reward.pop(int(t_int))
  ai_death(playername, loot)

def ai_death(playername, loot):
  backpack_length = player.player_backpack_length()
  if backpack_length > 15:
    print("Your backpack is full.")
    with open('./Players/' + playername + '/' + playerlocation + '.txt','a+') as file:
      file.write('' + loot + '\n')
    alt_second_module.prompt()
  else:
    print("For your effort you gained a " + loot + "")
    with open('./Players/' + playername + '/inventory.txt','a+') as file:
      file.write('' + loot + '\n')
    print("Your health: " + str(player.health) + "")
    alt_second_module.prompt()
    
  

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 17:55:49 2020

@author: jengwall
"""


#def main():
#    print("First Module's Name: {}".format(__name__))

#if(__name__=='__main__'):
#    main()
#    print("Run Directly")
#    main()

#    print("First Module's Name: {}".format(__name__))
#else:
#    print("Run Remotely")
    
    
    
    
#######################################################################################################
#         developed by Jonathan Engwall, October of 2018 in Tijuana, MX                               #
#               PYTHON CMD CRUD MUD: FEAR THEE TREAD INTERACTIVE FICTION                              #
#         	ENGWALLJONATHANTHEREAL@GMAIL.COM **2018**                                             #
#######################################################################################################

import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import time
from time import sleep
import math
import csv
import functools

import alt_first_module
import alt_second_module
#alt_second_module.get_backpack_contents()
#alt_second_module.main_game_loop()
#######################################################################################




from FearTheeZoneMap import *

from Items import *
from Players import *
from Lists import *
from Rooms import *






def title_screen_message(message):
  print('\n')
  print('' + message + '\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00 00 00000000 00000000000 00  0000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 00 00000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 0 000 00000000000000 00000000000000000000000000000000')
  print('00 00 00 000 0 000 00 0  0 000000000000000000 0 000   000 0 0 0 0 00000000000000')
  print('00 00 0 0 0 00 0 00 0  000 0 000 0 0 000 000 00 00 0000 0 000 000 00000000000000')
  print('00 00 0 0 0 00 0 0000 0000 00 00 0 00 0 00 0 00 00 0000 0 000 000 00000000000000')
  print('000  00 0 00 0000   0 0000 00  0 0 00 00 00000 0000   000 000 000 00000000000000')
  print('000000000000000000000000000000000000000000 0000000000000000000000000000000000000')
  print('0000000000000000000000000000000000000 000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

def title_screen_selections():
  choice = input("Command: ")
  while choice.lower() in ['new game','exit','resume']:
    if choice.lower() == ("exit"):
      sys.exit(0)
    elif choice == '':
      title_screen()
    elif choice.lower() == ("new game"):
      setup_game()
    elif choice.lower() == ("resume"):
        class thing:
          def __init__(self):
            self.name = name
            self.contents = contents
        
        class backpack:
          def __init_(thing):
            backpack.name = ''
            backpack.contents = []
        
        class living:
          def __init__(self):
            self.name = name
            self.location = location
            self.health = health
            
        class player:
          def __init__(living):
            player.name = ''
            player.attack = 2
            player.magic = 1
            player.health = 110
        #    player.location = '1_1'
            player.card = ''
            player.game_over = False
        alt_second_module.get_backpack_contents()
    else:
      title_screen()
      
    while choice.lower() not in ['new game', 'exit','resume']:
      print("Please enter a valid command: New Game - Exit - Resume")
      choice = input("Command: ")
      if choice.lower() == ("exit"):
        sys.exit(0)
      elif choice.lower() == (''):
        sys.exit(0)
      elif choice.lower() == ("new game"):
        setup_game()
      elif choice.lower() == ("resume"):
        class thing:
          def __init__(self):
            self.name = name
            self.contents = contents
        
        class backpack:
          def __init_(thing):
            backpack.name = ''
            backpack.contents = []
        
        class living:
          def __init__(self):
            self.name = name
            self.location = location
            self.health = health
            
        class player:
          def __init__(living):
            player.name = ''
            player.attack = 2
            player.magic = 1
            player.health = 110
        #    player.location = '1_1'
            player.card = ''
            player.game_over = False
        alt_second_module.get_backpack_contents()
      else:
        title_screen()

def title_screen():
  os.system('clear')
  print('\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00 00 00000000 00000000000 00  0000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 00 00000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 0 000 00000000000000 00000000000000000000000000000000')
  print('00 00 00 000 0 000 00 0  0 000000000000000000 0 000   000 0 0 0 0 00000000000000')
  print('00 00 0 0 0 00 0 00 0  000 0 000 0 0 000 000 00 00 0000 0 000 000 00000000000000')
  print('00 00 0 0 0 00 0 0000 0000 00 00 0 00 0 00 0 00 00 0000 0 000 000 00000000000000')
  print('000  00 0 00 0000   0 0000 00  0 0 00 00 00000 0000   000 000 000 00000000000000')
  print('000000000000000000000000000000000000000000 0000000000000000000000000000000000000')
  print('0000000000000000000000000000000000000 000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()  
    

    
    



#######################################################################################################
#                                                                                                     #
#                                          make the player                                            #
#######################################################################################################


    
    
def main_game_loop():
  while player.game_over is False:
    alt_second_module.prompt()







def setup_game():
  question = "Greetings adventurer. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
    entry = input("Your Name: ")
    if bool(re.match("^[A-Za-z0-9]*$", entry)) == False:
      print("Use only Letters or Numbers without Whitespace.\n")
      time.sleep(0.04)
      setup_game()
    if entry == '':
      print("Use Letters or Numbers to create your playername.\n")
      time.sleep(0.04)
      setup_game()
    else:
      welcome = "Okay, " + entry + " let's begin. You need to know a few things.\n"
      for character in welcome:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.03)

    help = "### Verbs are available and certain language processing. The basic CMDS \n" 
    help1 = "### are: look, get, drop, hold, show more, challenges, and move. You \n"
    help2 = "### have a certain amount of Health, check this with: status, and you \n"
    help3 = "### can only explore Underkingdom for a certain amount of time. Use: \n"
    help4 = "### clock to make sure you do not get trapped!\n\n"
    help5 = "### If you do get stuck, you can quit and start again at the beginning. \n"
    help6 = "### Set your terminal at 80x30. And remember it is just a game!\n\n"
    for character in help:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help1:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help2:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help3:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help4:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help5:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help6:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)

    goodluck = "\n\n\nOkay, " + entry + " you will be you and the clock starts ticking now!!!\n"
    for character in goodluck:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.08) # was time.sleep(0.08)
      os.system('clear')
      os.system("mkdir ./Players/" + entry) 
      os.system("cd ./Players/" + entry)
      os.system("touch __init__.py")
      os.system("cd ..")
      os.system("cp -r ./Rooms/* ./Players/" + entry)
      treasury_stripe(entry)
      holding_stripe(entry)
      wearing_stripe(entry)
      player_files(entry)
      new_holding(entry)
      new_inv(entry)
      new_treas(entry)
      new_victories(entry)
      run_intro(entry)
      entry = playername
      playername = player.name
#      run_game(playername)
      



class thing:
  def __init__(self):
    self.name = name
    self.contents = contents

class backpack:
  def __init_(thing):
    backpack.name = ''
    backpack.contents = []

class living:
  def __init__(self):
    self.name = name
    self.location = location
    self.health = health



  
      
      
class player:
  def __init__(living):
    player.name = ''
    player.attack = 2
    player.magic = 1
    player.health = 110
    player.location = '1_1'
    player.card = ''
    player.game_over = False
    
    



#######################################################################################################
#                                                                                                     #
#                                          make the player                                            #
#######################################################################################################



def player_get_attack():
  player.name = player.name
    
  with open('./Players/' + player.name + '/holding.txt','r') as file:
    my_weapons = file.read()
    if '' in my_weapons:
      player.attack += 1
    if 'Bronze Sword' in my_weapons:
      player.attack += 5
    if 'Shovel' in my_weapons:
      player.attack += 6
    if 'Wand' in my_weapons:
      player.attack += 2
      player.magic += 1
############################################################################################
    if 'Axe' in my_weapons:
      player.attack += 3     
    if 'Scimitar' in my_weapons:
      player.attack += 7 
    if 'Battle Axe' in my_weapons:
      player.attack += 8
    if 'Spear' in my_weapons:
      player.attack += 6
    if 'Knife' in my_weapons:
      player.attack += 3   
    if 'Flail' in my_weapons:
      player.attack += 7
############################################################################################
    if 'Thirty Silver Coins' in my_weapons:
      player.attack += 1

    with open('./Players/' + player.name + '/wearing.txt','r') as file:
      my_armor = file.read()
      if '' in my_armor:
        player.attack += 1
      if 'Cloak' in my_armor:
        player.attack += 5
############################################################################################
      if 'Bronze Plate Mail' in my_armor:
        player.attack += 20
      if 'Buckler' in my_armor:
        player.attack += 5
      if 'Studded Leather' in my_armor:
        player.attack += 6
      if 'Ring Mail' in my_armor:
        player.attack += 8
      if 'Plate Mail' in my_armor:
        player.attack += 15
      if 'Elfin Chain Mail' in my_armor:
        player.attack += 11
############################################################################################
      if 'Pendant of Philemon' in my_armor:
        player.attack += 1
        player.magic += 5
      if 'Ring of Delusion' in my_armor:
        player.attack += 2
        player.magic += 1
      if 'Ring of Fire Resistance' in my_armor:
        player.attack += 6
        player.magic += 1
      if 'Ring of Mind Shielding' in my_armor:
        player.attack += 1
        player.magic += 8
      if 'Ring of Blinking' in my_armor:
        player.attack += 6
        player.magic += 1
      if 'Ring of Protection' in my_armor:
        player.attack += 4
        player.magic += 4
      if 'Ring of Human Influence' in my_armor:
        player.attack += 2
        player.magic += 5
      if 'Ring of Shocking Grasp' in my_armor:
        player.attack += 3
        player.magic += 7
      if 'Ring of Delusion' in my_armor:
        player.attack += 3
        player.magic += 2
      if 'Ring of Contrariness' in my_armor:
        player.attack += 1
        player.magic += 6
      if 'Ring of Anything' in my_armor:
        player.attack += 1
        player.magic += 3
      
      playerattack = (int(player.attack) + int(player.magic))
      return playerattack

def player_get_weapon():
  player.name = player.name
  playerweapon = ''
  file = open('./Players/' + player.name + '/holding.txt','r')
  my_weapons = file.read()
  if '' in my_weapons:
    playerweapon = 'bare hands'
  elif 'Bronze Sword' in my_weapons:
    playerweapon = 'bronze sword'
  elif 'Shovel' in my_weapons:
    playerweapon = 'shovel'
  elif 'Wand' in my_weapons:
    playerweapon = 'wand'
############################################################################################
  elif 'Axe' in my_weapons:
    playerweapon = 'Axe'
  elif 'Scimitar' in my_weapons:
    playerweapon = 'Scimitar'
  elif 'Battle Axe' in my_weapons:
    playerweapon = 'Battle Axe'
  elif 'Spear' in my_weapons:
    playerweapon = 'Spear'
  elif 'Knife' in my_weapons:
    playerweapon = 'Knife'
  elif 'Flail' in my_weapons:
    playerweapon = 'Flail'
############################################################################################
  else:
    alt_second_module.prompt()
  file.close()
  return playerweapon

def player_get_dam_mesg():
  player.name = player.name
  player_dam_mesg = []
  file = open('./Players/' + player.name + '/holding.txt','r')
  my_weapons = file.read()
  if '' in my_weapons:
    player_dam_mesg = ['scratch','punch','slap']
  elif 'Bronze Sword' in my_weapons:
    player_dam_mesg = ['land a wild slash','open a deep cut','sink in a nice jab']
  elif 'Shovel' in my_weapons:
    player_dam_mesg = ['make contact with a solid whack','send a split down the middle','swing upward and land a hard smack']
  elif 'Wand' in my_weapons:
    player_dam_mesg = ['send a sizzling blast','call up a cone of freeze','summon a terrific blast']
############################################################################################
  elif 'Axe' in my_weapons:
    player_dam_mesg = ['','','']
  elif 'Scimitar' in my_weapons:
    player_dam_mesg = ['','','']
  elif 'Battle Axe' in my_weapons:
    player_dam_mesg = ['','','']
  elif 'Spear' in my_weapons:
    player_dam_mesg = ['','','']
  elif 'Knife' in my_weapons:
    player_dam_mesg = ['','','']
  elif 'Flail' in my_weapons:
    player_dam_mesg = ['','','']

  else:
    alt_second_module.prompt()
  file.close()
  return player_dam_mesg

def player_get_fights():
  player.name = player.name
  with open('./Players/' + player.name + '/victories.txt','r') as file:
    victories_len = file.readlines()
    fights = len(victories_len)
    return fights

#############################################################################################

#global player
#player = player()

#global playername
#playername = player.name

#######################################################################################################
#                                                                                                     #
#                                          necc. introduction art                                     #
#######################################################################################################


#######################################################################################################
#                                                                                                     #
#                                          combat and logic for AI                                    #
#######################################################################################################

 ################################################################################
#                                                                                #
#                          OUR VILLAINS                                          #

global ai

class Ai:
  def __init__(self, health, attack, name, dead=''):
    self.health = health
    self.attack = attack
    self.name = name
    self.dead = dead


################################################################
def new_victories(playername):
  file = open('./Players/' + playername + '/victories.txt','w+')
  file.close()


def run_intro(playername):
#  player.name = playername
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()
  os.system('clear')
#  welcome = "\n\n\nWelcome to the Under Kingdom\n"
#  for character in welcome:
#    sys.stdout.write(character)
#    sys.stdout.flush()
#    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nWelcome to the Border Land!\nWhat adventure awaits!\n\n')
  player.location = 'xxxxxxxxx'
  print('Pinklemire Street.\n.\n\n')
  print("To the North is the Blacksmith\nTo the South is the Message Post\nTo the East is the Leather Shop\nTo the West is the Pub\n")
  with open('./Players/' + playername + '/xxxxxxxxx.txt','r+') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
      player.name=playername
    first_module.main_game_loop()




screen_width = 80

combat_state = 0
combat_round = 0

def treasury_stripe(playername):
  inv = open('./Players/' + playername + '/treasuryList.txt','w+')
  with open('./Lists/treasuryList.txt','r') as file:
    basics = file.readlines()
    for basic in basics:
      inv.write(basic)
      continue
    inv.close()

def holding_stripe(playername):

  file = open('./Items/holding.txt','r')
  basics = file.readlines()
  h_inv = open('./Players/' + playername + '/holding.txt','w+')
  for basic in basics:
    h_inv.write(basic)
    continue
  file.close()
  h_inv.close()

def wearing_stripe(playername):

  file = open('./Items/wearing.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + playername + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
 
def clothing_stripe():
  file = open('./Lists/clothing.txt','r')
  file.close()

def weaponOrTool_stripe():
  file = open('./Lists/weaponOrTool.txt','r')
  file.close()

def treasure_stripe():
  file = open('./Lists/treasure.txt','r')
  file.close()

def player_files(playername):
  file = open('./Players/' + playername + '/wearing.txt','r')
  file.close()

def new_holding(playername):
  file = open('./Players/' + playername + '/holding.txt','r')
  file.close()

def new_inv(playername):
  file = open('./Players/' + playername + '/inventory.txt','w+')
  file.close()
  file = open('./Players/' + playername + '/inventory.txt','r')
  file.close()

def new_treas(playername):
  file = open('./Players/' + playername + '/treasuryList.txt','r')
  file.close()

    
    

  


################################################################



  

  
#title_screen()
    
    
#######################################################################################################
#      here is a hard coded element                                                                   #                                              
#                                       save game                                                     #
#######################################################################################################

def load_backpack(name):
  location = player.location
  save_room = input("Save your current location?\nYes or No.\n")
  if save_room.lower() in 'no':
    file = open('./Players/' + name + '/startlocation.txt','w+')
    file.write('1_1')
    file.close()
    save_name(name)
  else:
    file = open('./Players/' + name + '/startlocation.txt','w+')
    file.write(location)
    file.close()
    save_name(name)

def save_name(name):
  file = open('./Lists/player_card.txt','r')
#  playername = player.name.lower()
  players = file.read()
  if name not in players:
    file.close()
    file = open('./Lists/player_card.txt','a+')
    file.write('\n' + name + '')
    file.close
    close_all_files()
  else:
    file.close()
    close_all_files()

def close_all_files():
  sys.exit(0)

#######################################################################################################
#                                                                                                     #                                     delete   
#                                                                                                     #
#######################################################################################################

def end_game(name):
#  playername = player.name
  with open('./Lists/player_card.txt','r') as file:
    players = file.readlines()
    with open('./Lists/player_card.txt','w+') as remove_player:
      for player in players:
        if player != name:
          remove_player.write(player)
          continue
        continue
  os.system("cd ./Players/")
  os.system("rm -rf " + str(name) + "")
  sys.exit(0)

    
    
    
    
    
    
    
    
    

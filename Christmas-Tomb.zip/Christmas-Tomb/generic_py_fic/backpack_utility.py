  file = open('./Players/' + my_player.name + '_inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    file = open('./Players/' + my_player.name + '_inventory.txt','a+')
    file.write('' + str(want) + '\n')
    file.close()
    prompt()

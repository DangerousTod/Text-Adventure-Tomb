      file = open('./Players/' + my_player.name + '_inventory.txt','r')
      items = file.readlines()
      line_write_file = open('./Players/' + my_player.name + '_inventory.txt','w')
      for item in items:
        if item != ('' + str(clothing_c) + '\n'):
          line_write_file.write(item)
          continue
        continue
      file.close()
      line_write_file.close()

######################################################
#        update player master list                   #                                              ###################################################### 
def move_bronze(new_item):
  file = open('./Players/' + my_player.name + '_treasuryList.txt','r')
  contents = file.read() 
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '_treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '_treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_bronze(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()

######################################################
#        check pack + add item                       #                                              ######################################################
def add_bronze(new_item):
  file = open('./Players/' + my_player.name + '_inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    my_player.attack += 5
    print("You take the bronze sword from behind the curtain.\n")
    file = open('./Players/' + my_player.name + '_inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt()

######################################################
#        check redundant item                        #                                              ######################################################
def get_bronze():
  new_item = ('bronze sword')
  file = open('./Players/' + my_player.name + '_inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_bronze(new_item)

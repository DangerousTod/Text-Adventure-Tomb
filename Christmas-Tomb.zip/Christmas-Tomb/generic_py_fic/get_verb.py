######################################################
#        update player master list                   #                                              ###################################################### 
def move_object(new_item):
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_object(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()

######################################################
#        check pack + add item                       #                                              ######################################################
def add_object(new_item):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else: 
    print('You take the ' + new_item + '.\n')
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt()

######################################################
#        check redundant item                        #                                              ######################################################
def get_object(obj):
  new_item = obj
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_object(new_item)

def examine():
  print('You find a ' + obj + '.\n')
  cmd = input('Type: get ' + obj + ' and you will to pick it up!')

  if cmd == ('get ' + obj + ''):
    file = open('./Players/Room/' + my_player.location + '.txt','r')
    room_contents = file.read()
    file.close()
    if obj in room_contents:
      get_object(obj)

  elif cmd in ['go back']:
    prompt()
  else:
    cmd = input('Type: get ' + obj + ' and you will to pick it up!')
    if cmd == ('get ' + obj + ''):

      file = open('./Players/Room/' + my_player.location + '.txt','r')
      room_contents = file.read()
      file.close()
      get_object(obj)

    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()


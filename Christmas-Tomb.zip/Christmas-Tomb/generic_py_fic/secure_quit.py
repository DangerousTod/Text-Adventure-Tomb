  elif action.lower() == ("quit"):
    quit_logo = input("Save Game For You?\nYes or No: \n")
    if quit_logo.lower() in ('yes'):
      load_backpack()
    else:
      print("Warning: Any reply other than 'yes' will delete your player completely!!!\n")
      secure_quit = input("Yes to save this player and progress!!!\n")
      if secure_quit.lower() in ('yes'):
        load_backpack()
      else:
        end_game()

def accomplish_ check_point():
  global check_point
  check_point = 0
  print("\n\nCheck Point.\nDo you have a <necessary item one>?\n")

  cmd = input("Yes or No.\n")
  if cmd in ['yes']:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    item_search = file.read()

    if '<necessary item one>' not in item_search:
      file.close()
      print("You do not have a <necessary item one>.\n")
      prompt()

    else:
      print("Stage Two.\n")
      print("<necessary item two>?\n")
      n_cmd = input("Yes or No.\n")

      if n_cmd in ['yes']:
        file = open('./Players/' + my_player.name + '/inventory.txt','r')
        item2_search = file.read()

        if '<necessary item two>' not in item2_search:
          file.close()
          print("You do not have <necessary item two>.\n")
          prompt()

        else:
          print("Success.\n")
          check_point += 1

      else:
        prompt()
  else:
    prompt()   

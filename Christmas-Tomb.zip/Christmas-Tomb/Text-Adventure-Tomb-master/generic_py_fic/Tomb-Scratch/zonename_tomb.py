

zonemap = {

  'Darkened_Stairway': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You are on the Darkened Stairway.\n\n' +
'A Chute leads Down from Here\n\n' +
'The Chute seems to be a slide...\n\n' +
'Type: move and then Type: down when you are ready.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: 'Bottom_of_Chute',
	ITEM: '\n'
  },
  'Bottom_of_Chute': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You are at the bottom of a chute. Alone and trapped in total darkeness...\n' +
'just then your electric torch sizzles and lights up the room.\n\n' +
'To the West is a Door...\n' +
'However the door is terribly ugly and solidly locked.\n\n' +
'You cannot reach the bottom of the chute. It is too high for you to jump up \n' +
'and grab. You cannot find even something you can drag to the chute to \n' +
'stand on.\n\n' +
'The giant green face on the door suddenly comes alive! Tell me \n' + 
player_name + ' are you still having fun? I hope so, I hope I am not too \n' +
'scary because I have a riddle for you...\n\n' +
'What sings, has one arm and turns round and round and round?\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Do you know the answer?\n2.) Do you need a hint?\n3.) Would you like a new riddle?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Water_Fountain': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You stand beside a water fountain.\n\n' +
'To the North is a Hallway\n' +
'To the South is a Hallway\n' +
'A Hallway sloped Down from Here\n\n' +
'\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Faded_Tapestries',
	SOUTH: 'Library',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: 'Room_of_Faces',
	ITEM: '\n'
  },
  'Library': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You are in the underground library.\n\n' +
'To the North is a Door\n\n' +
'\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Water_Fountain',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Room_of_Faces': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You balance on the stone aisle between the two channels of water following \n' +
'them down into a large dome shaped room. \n\n' +
'A hallway leads upward.\n\n' +
'Within the dome shaped room are four silent stone faces each looking down. \n' +
'Their heads are bowed and their eyes are closed. They do not move, they do \n' +
'now speak, they are simply looking downward. The water from the water \n' +
'fountain flows into their big open mouths.\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: 'Water_Fountain',
        DOWN: '',
	ITEM: '\n'
  },
  'Faded_Tapestries': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'This is the Hall of Tapestries. Perhaps a king lived here long long ago...\n' +
'Anything can happen in New Jersey, right?\n\n' +
'To the South is a Hallway\n' +
'To the East is Large Blue Door\n\n' +
'\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Water_Fountain',
	EAST: 'Singing_Crystals',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Singing_Crystals': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'Around you are thousands of tiny singing crystals.\n\n' +
'To the South is a Large Green Door\n' +
'\n\n' +
'\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Inner_Chamber',
	EAST: '',
	WEST: 'Faded_Tapestries',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Stairway_and_Candles': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You have seen some odd things in the past few hours, this is downright mond \n' +
'boggling. In front of you is a stairway lit by hundreds of candles leading \n' +
'up to the stone wall at the southern end of this subterreanean maze.\n\n' +
'To the North is a Hallway\n\n' +
'The candles do not seem to run out of fuel. Their light is warm and constant. \n' +
'The wall, unlike the others walls where the rock is either natural or filled \n' +
'in with large stone blocks is a broad flat void of stone with no indication \n' +
'as to why candles and a stairway are here.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Inner_Chamber',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Inner_Chamber': {
	ZONENAME: 'tomb',
      # 80 Columns   ########################################################L#####################
	DESCRIPTION: 
'You are in the Inner Chamber.\n\n' +
'To the North is a Large Green Door\n' +
'To the South is a Hallway\n\n' +
'\n\n' +
'\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Singing_Crystals',
	SOUTH: 'Stairway_and_Candles',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
}

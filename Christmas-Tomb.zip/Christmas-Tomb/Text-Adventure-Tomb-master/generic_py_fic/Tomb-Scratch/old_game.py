def title_screen_selections():
  choice = input("Command: ")
  while choice.lower() in ['new game','quit','resume']:
    if choice.lower() == ("quit"):
      sys.exit()
    elif choice.lower() == ("new game"):
      setup_game()
    else:
      choice.lower() == ("resume"):
        resume_game()
      return
    while choice.lower() not in ['new game', 'quit']:
      print("Please enter a valid command: New Game or Quit")
      choice = input("Command: ")
      if choice.lower() == ("quit"):
        sys.exit()
      elif choice.lower() == ("new game"):
        setup_game()
      else:
        choice.lower() == ("resume"):
        resume_game()
        return



def resume_game()
  file = open('players.txt','r')
  contents = file.read()
  print(contents)
  name = input("Which of these names would you like to reuse?")
  if name in contents:
    file.close()
    name = player_name
    my_player = player_name
    run_game()
  else:
    new_game = input("This is a new name.\nCreate new game, Yes or No.")
    if new_game.lower() in ['yes']:
      add_file = open('players.txt','a')
      add_file.write(name)
      file.close()
      add_file.close()
      my_player = player_name
      inventory_restore()
    else:
      title_screen()





def inventory_restore():
  file = open('inventory.txt','r')
  my_invs = file.readlines()
  my_stuff = open('' + my_player.name + '.txt','w+')
  for my_inv in my_invs:
    my_stuff.write(my_inv)
    continue
    file.close()
    my_stuff.close()
  wearing_restore()

def we




def setup_game():

  question = "\nHello, I hope you are ready for a scare. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  player_name = input("Your Name: ")

  add_file = open('players.txt','a')
  add_file.write(player_name)

  add_file.close()


  my_player.name = player_name
  run_game()

def run_game()

  welcome = "Okay, " + player_name + " let's begin. You need to know a few things.\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.03)

  help = "### Verbs are available and certain language processing. The basic CMDS \n" 
  help1 = "### are: look, get, drop, hold, show more, challenges, and move. You \n"
  help2 = "### have a certain amount of Health, check this with: status, and you \n"
  help3 = "### can only explore The Tomb for a certain amount of time. Use: clock \n"
  help4 = "### to make sure you do not get trapped in The Tomb!\n\n"
  help5 = "### If you do get stuck, you can quit and start again at the beginning. \n"
  help6 = "### And remember it is just a game!\n\n"
  for character in help:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help1:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help3:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)

  goodluck = "\n\n\nOkay, " + player_name + " you will be you and the clock starts ticking now!!!\n"
  for character in goodluck:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.08) # was time.sleep(0.08)
  os.system('clear')

  inventory_stripe()
  holding_stripe()
  weaponOrTool_stripe()
  clothing_stripe()
  wearing_stripe()
  treasure_stripe()
  run_game()

def run_game():
  bigblackdoor = "\n\n\nTHE BIG BLACK DOOR CREAKS OPEN...\n"
  for character in bigblackdoor:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nGREAT_HALL\nA flurry of bats suddenly flaps through the doorway, their screeching barely \n' +
'audible as they careen past your head. They flap past you into the rooms \n' +
'and halls beyond. The room from which they came seems barren at first glance.\n\n' +
'An old clock stands at the north side of the room between two cobweb covered \n' +
'bookshelves. It clicks loudly. Its winding is too slow and the gears rattle \n' +
'with every passing tick.\n\n' +
'To the East is a Door\n\n' +
'High above the bookshelf is a large round window. It is cloudy with dirt and \n' +
'age. Another window just like it is high up on the east wall just below the \n' +
'carved wooden rafters. On the south wall are dozens of oil paintings, normal \n' +
'haunted house paintings of ancestors of people who are long since gone away \n' +
'posing like royalty wearing kilts beside a fire as dogs roll about at foot. Yet \n' +
'behind you there is no window. You turn and look and sure enough a thick black \n' +
'curtain covers nearly the entire wall. It is only pulled back enough for the \n' +
'door to swing inward.\n\n' +
'The clock rattles again. The poor thing almost seems to be in pain. Maybe you \n' +
'can fix it. The glass door has a handle.\n\n')

  main_game_loop()

title_screen()

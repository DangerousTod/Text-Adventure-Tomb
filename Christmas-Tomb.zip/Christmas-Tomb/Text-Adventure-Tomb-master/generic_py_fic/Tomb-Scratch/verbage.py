def get(self, object):
  cmd = input('get ' + item + '')
  object = cmd
  object.name('' + item + '')
  if object.size == False:
    print("You cannot get an item of this size.\n")
    prompt()
  else:

    file = open('./Players/Room/' + my_player.location + '.txt','r')
    room_contents = file.readlines()
    move_item = open('./Players/Room/' + my_player.location + '.txt','w')
    for room_content in room_contents:
      item != room_content:
        move_item.write(room_content)
        continue
      continue
      file.close()
      move_item.close()
    elif:
      print('' + item + ' not found.\n')
      file.close()
      move_item.close()
      prompt()
    else:
      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      inventory = file.readlines()
      file.close()
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write(item)
      file.close()
      player.attack += attackbonus
      player.magic += magicbonus
main_game_loop()

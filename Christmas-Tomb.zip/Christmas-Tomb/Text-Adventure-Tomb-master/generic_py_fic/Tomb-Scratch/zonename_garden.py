
zonemap = {

  'Graveyard': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Graveyard.\n\n' +
'To the North is the Gardeners Shed\n\n' +
'To the West is a Patch of Weeds\n\n' +
'Hopefully you are only visiting.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Read Tombstone?\n2.) Watch for the Gardener?\n3.) Examine Pile of Stones?\n',

	SOLVED: False,
	NORTH: 'Shed_Door',
	SOUTH: '',
	EAST: '',
	WEST: 'Weeds',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Gardeners_Shed': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in the Gardeners Shed.\n\n' +
'To the West is a Door\n\n' +
'Junk is everywhere in a vague organization of things on metal shelves\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine Broken Lawnmower?\n2.) Search Workbench?\n3.) Examine Gears?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: 'Shed_Door',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Kitchen_Door': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are at the Kitchen Door of the Old Mansion.\n\n' +
'To the East is a Patch of Weeds\n\n' +
'To the West is the Kitchen\n\n' +
'You can wait, nothing will be for dinner.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Examine Leaking Hose?\n2.) Try to Fix Broken Bench?\n3.) Examine Flower Pots?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: 'Weeds',
	WEST: 'Kitchen',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Shed_Door': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are the Door of the Gardeners Shed.\n\n' +
'To the South is a Graveyard\n\n' +
'To the East is the Door of the Gardeners Shed\n\n' +
'To the West is a Vegetable Patch\n\n' +
'The Gardener comes and goes from here often.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Catch a Grasshopper?\n2.) Sneak Around the Gardeners Shed?\n3.) ?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Graveyard',
	EAST: 'Gardeners_Shed',
	WEST: 'Vegetable_Patch',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Weeds': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are in a weed patch at the back of the Mansion.\n\n' +
'To the North is a Vegetable Patch\n\n' +
'To the East is a Graveyard\n\n' +
'To the West is the Mansion\n\n' +
'Instead of mowing down the weeds the Gardener simply clears a patch between \n' +
'the Shed, the Graveyard and the Mansion.\n\n',
#	EXAMINATION: '\n\nChallenges:\n1.) ?\n2.) ?\n3.) ?\n',

	SOLVED: False,
	NORTH: 'Vegetable_Patch',
	SOUTH: '',
	EAST: 'Graveyard',
	WEST: 'Kitchen_Door',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
  'Vegetable_Patch': {
	ZONENAME: 'garden',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 
'You are at the Edge of a small Vegetable Patch.\n\n' +
'To the South is a Weed Patch\n\n' +
'To the East is the Gardeners Shed\n\n' +
'Various peppers grow in the Vegetable Patch along side tomatoes, a string of \n' +
'carrots, a few marigolds and five large sunflowers.\n\n',
	EXAMINATION: '\n\nChallenges:\n1.) Gather Sunflower Seeds?\n2.) Squish Tomatoes?\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: 'Weeds',
	EAST: 'Shed_Door',
	WEST: '',
        UP: '',
        DOWN: '',
	ITEM: '\n'
  },
}

def read_tombstone():
  pass

def watch_for_gardener():
  pass

def examine_pile_stones():
  pass

def examine_hose():
  pass

def fix_bench():
  pass

def examine_flowerpots():
  pass

def examine_lawnmower():
  pass

def search_workbench():
  pass

def examine_gears():
  pass

def catch_grasshopper():
  pass

def sneak_around_shed():
  pass

def gather_sunflower_seeds():
  pass

def squish_tomatoes():
  pass

#Challenges:\n1.) Read Tombstone?\n2.) Watch for the Gardener?\n3.) Examine Pile of Stones?\n',
  if playerlocation in ['graveyard']:
    
    if myCommandX == ('1'):
      read_tombstone()
    elif myCommandX == ('2'):
      watch_for_gardener()
    elif myCommandX == ('3'):
      examine_pile_stones()

#Challenges:\n1.) Examine Leaking Hose?\n2.) Try to Fix Broken Bench?\n3.) Examine Flower Pots?\n',
  if playerlocation in ['kitchen_door']:
    
    if myCommandX == ('1'):
      examine_hose()
    elif myCommandX == ('2'):
      fix_bench()
    elif myCommandX == ('3'):
      examine_flowerpots()

#Challenges:\n1.) Examine Broken Lawnmower?\n2.) Search Workbench?\n3.) Examine Gears?\n',
  if playerlocation in ['gardeners_shed']:
    
    if myCommandX == ('1'):
      examine_lawnmower()
    elif myCommandX == ('2'):
      search_workbench()
    elif myCommandX == ('3'):
      exdamine_gears()

#Challenges:\n1.) Catch a Grasshopper?\n2.) Sneak Around the Gardeners Shed?\n',
  if playerlocation in ['shed_door']:
    
    if myCommandX == ('1'):
      catch_grasshopper()
    elif myCommandX == ('2'):
      sneak_around_shed()

#Challenges:\n1.) Gather Sunflower Seeds?\n2.) Squish Tomatoes?\n',
  if playerlocation in ['vegetable_patch']:
    
    if myCommandX == ('1'):
      gather_sunflower_seeds()
    else myCommandX == ('2'):
      squish_tomatoes()


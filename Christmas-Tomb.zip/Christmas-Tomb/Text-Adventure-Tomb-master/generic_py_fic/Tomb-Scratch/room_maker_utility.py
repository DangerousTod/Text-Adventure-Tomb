
def ready_rooms():
  file = open('room-master.txt','r')
  file.close
  build_rooms()

def build_rooms():

  build = 0
  if build < 1:
    file = open('room-master.txt','r')
    room_writers = file.readlines()
    for room_writer in room_writers:

      file = open(room_writer + '.txt','w')
      continue
    file.close()
    build += 1
  else:
    sys.exit()

ready_rooms()

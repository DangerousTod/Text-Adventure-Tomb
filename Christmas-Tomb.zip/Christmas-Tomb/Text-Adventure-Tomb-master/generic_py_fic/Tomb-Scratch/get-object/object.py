class object:
  def __init__(thing):
    object.name = name
    object.size = True
    object.attackbonus = attackbonus
    object.magicbonus = magicbonus
    return object

  def __makeObject(self, name, size, attackbonus, magicbonus):
    object = Object(nm, sz, atb, mgb)
    object.name(self.name)
    object.size(self.size)
    object.attackbonus(self.attackbonus)
    object.magicbonus(self.magicbonus)
    return name, size, attackbonus, magicbonus

import textwrap
import time
import random
import math
import csv
from tomb_main import prompt

def take_keys():
  file = open('inventory.txt','r')
  my_contents = file.read()
        
  if 'steel keys' in my_contents:
    file.close()
    print("You already have the steel keys.\n")
    prompt()
  else:
    file.close()
    file = open('inventory.txt','a')
    file.write('steel keys\n')
    file.close
    prompt()

def examine_painting():
  print("\nWhat an ugly wierd, somehow adorable thing?\nThis place is getting into your head. Is it hanging crooked?\n")

  cmd = input("Do you want to straighten the painting?\n")
  ans = ['yes','I will','straighten the painting','okay','sure','I straighten the painting']

  if cmd in ans:
    print("\nThe painting wobbles then hangs straight.\nWhat is this? Is something behind the painting?")
    new_cmd = input("Do you want to check behind the painting?\n")
    decs = ['yes','I will','okay','sure']

    if new_cmd in decs:
      print("A pair of small steel keys are hanging behind the painting.\n")
      xmd = input("Type: 'take the keys' if you want the keys.\n")
      if xmd in ['take the keys']:
        take_keys()
      else:
        prompt()
    else:
      prompt()
  else:
    prompt()      


def ivan_turn():
  print("Oh my! There is a spook behind you!!!\n")
  my_player = player()
  ai = ghost()
  whereabouts = my_player.location.lower()
  battleground = ai.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  ai_fight(my_player, ai, battleground, playerlocation)

def no_ghosts():
  print("No such thing as ghosts! No such thing as ghosts!\nA little self talk should help.\n")

def examine_floor():
  print("Squeak and wobble, you follow it around and around.\n")
  prompt() 

def check_bookcase():
  pass

def jump_on_bed():
  pass

def look_out_window():
  pass

def search_items():
  print("The people who lived here saved almost everything. In the clutter loosely \norganized around their mattress they left everything from torn magazine covers \nto a toilet brush.\n")
  cmd = input("If there is something specific you need just type in now: \n")
  mess = ['nuts and bolts','comb','toilet brush','shoe horn','reading glasses','golfer pencil','rain jacket','makeup tin','jump rope']
  if cmd in mess:
    print("What luck! You find a " + str(cmd) + "!\n")
    file = open('inventory.txt','a')
    file.write('' + str(cmd) + '\n')
    file.close
    prompt()
  else:
    print("You don't find a " + str(cmd) + " in all the mess of things.\n")
    prompt()

def move_mattress():
  print("You struggle with the giant feather bed as long as you can. But it is no use. It just \nwon't budge.\n\n")
  prompt()

#######################################

def read_book():
  pass

def get_crystal():
  file = open('inventory.txt','a')
  file.write('crystal\n')
  file.close
  prompt()

def search_desk():
  print("You paw through the contents of the desk looking for anything that isn't broken \nor so caked with dirt you can't guess what it is supposed to be at all. \nWhat's this! A great big piece of quartz! And how weirdly it is wrapped with on one end \nwith copper wire. Very strange...\n")
  cmd = input("Type: 'get crystal' to pick it up\n")
  if cmd in ['get crystal']:
    get_crystal()
  else:
    prompt()

def other_books():
  pass

def check_clothes():
  print("Hmm...never anything in your size.\n")
  prompt()

def get_junk():
  file = open('inventory.txt','a')
  file.write('hat pin\nlocket\nflashlight\nmittens\n')
  file.close
  prompt()

def open_cabinets():
  print("Above the racks of clothing are a few interesting items which you might use \nor at least trade to a friend.\n")
  cmd = input("Type: 'get junk' to take these interesting things.\n")
  if cmd in ['get junk']:
    get_junk()
  else:
    prompt()

def tiny_chair():
  print("How silly this little chair is you must have thought, before you bumped into a loose \nloose panel in the wall. An entire room is there completely hidden. Type: 'move' and \nthen type: 'west' to enter this secret room.\n\n")
  prompt()

def listen():
  print("It is a good thing you took a moment to listen you can definetaly hear the ticking \nof the clock and also steady shuffling feet. Someone else is here.\n\n")
  prompt()

def examine_carpet():
  print("You pause to admire or at least try to admire to ghastly choice in floor covering. \nThe reds and golds wind together like snakes.\n\n")
  prompt()

def rescue_plant():
  print("You rescue a dying flower from the upstairs hallway.")
  file = open('inventory.txt','a')
  file.write("potted plant\n")
  file.close()
  prompt()


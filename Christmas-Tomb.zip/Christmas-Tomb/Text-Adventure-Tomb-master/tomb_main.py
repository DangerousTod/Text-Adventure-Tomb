#######################################################################################################
#         developed by Jonathan Engwall, October of 2018 in Tijuana, MX                               #
#               PYTHON CMD CRUD MUD: THE TOMB INTERACTIVE FICTION                                     #
#         	ENGWALLJONATHANTHEREAL@GMAIL.COM **2018**                                             #
#######################################################################################################

import textwrap
import sys
import os
import random
import math
import csv
import functools
#import pandas

from time import sleep
from zonemap import *
from masterList import *
#from memo import *

from Items import *
from Players import *
from Lists import *
from Rooms import *

screen_width = 80

combat_state = 0
combat_round = 0

#######################################################################################################
#                                                                                                     #
#                                          make the player                                            #
#######################################################################################################

class thing:
  def __init__(self):
    self.name = name
    self.contents = contents

class backpack:
  def __init_(thing):
    backpack.name = ''
    backpack.contents = []

class living:
  def __init__(self):
    self.name = name
    self.location = location

class player:
  def __init__(living):
    player.name = ''
    player.attack = 2
    player.magic = 1
    player.health = 110
    player.location = 'Great_Hall'
    player.card = ''
    player.game_over = False

  def my_player_get_attack():
    my_player.name = my_player.name
    
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      player.attack += 5
    elif 'shovel' in my_weapons:
      player.attack += 6
    elif 'wand' in my_weapons:
      player.attack += 2
      player.magic += 1
    elif 'thirty silver coins' in my_weapons:
      player.attack += 1
    else:
      prompt()
    file.close()
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    my_armor = file.read()
    if 'cloak' in my_armor:
      player.attack += 5
    if 'pendant of philemon' in my_armor:
      player.attack += 1
      player.magic += 5
    file.close()
    playerattack = (int(player.attack) + int(player.magic))
    return playerattack

  def my_player_get_weapon():
    my_player.name = my_player.name
    playerweapon = ''
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      playerweapon = 'bronze sword'
    elif 'shovel' in my_weapons:
      playerweapon = 'shovel'
    elif 'wand' in my_weapons:
      playerweapon = 'wand'
    else:
      prompt()
    file.close()
    return playerweapon

  def my_player_get_dam_mesg():
    my_player.name = my_player.name
    player_dam_mesg = []
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      player_dam_mesg = ['land a wild slash','open a deep cut','sink in a nice jab']
    elif 'shovel' in my_weapons:
      player_dam_mesg = ['make contact with a solid whack','send a split down the middle','swing upward and land a hard smack']
    elif 'wand' in my_weapons:
      player_dam_mesg = ['send a sizzling blast','call up a cone of freeze','summon a terrific blast']
    else:
      prompt()
    file.close()
    return player_dam_mesg

#######################################################################################################
#                                                                                                     #
#                                          enemy options and global                                   #
#######################################################################################################

class vampire:
  def __init__(self):

    self.name = 'Vampire'
    self.attack = 6
    self.health = 300
    self.location = 'Tropy_Room'
    self.dead = False

class zombie:
  def __init__(self):

    self.name = 'zombie'
    self.attack = 5
    self.health = 50
    self.location = 'Kitchen'
    self.dead = False

class bat:
  def __init__(self):

    self.name = 'bat'
    self.attack = 8
    self.health = 200
    self.location = 'Study'
    self.dead = False

class ghost:
  def __init__(self):

    self.name = 'ghost'
    self.attack = 1
    self.health = 400
    self.location = 'Stairway'
    self.dead = False

global my_player
my_player = player()

global playername
playername = my_player.name

global ai
ai = vampire()
ai = zombie()
ai = bat()
ai = ghost()

#######################################################################################################
#                                                                                                     #
#                                          necc. introduction art                                     #
#######################################################################################################

def get_backpack_contents():
  file = open('./Lists/player_card.txt','r')
  contents = file.read()
  print(contents)
  file.close()
  player_name = input("Choose the player to resume from this list\nChoose player: \n")

  file = open('./Lists/player_card.txt','r')
  strict = file.read()

  if player_name.lower() in strict.lower():
    file.close()
    hold_ready(player_name)
  else:
    file.close()
    os.system('clear')
    message = "Player not found.\nRemember to match spelling and capitalization."
    title_screen_message(message)

def hold_ready(player_name):
  file = open('./Players/' + player_name +'/holding.txt','r')
  file.close()
  wear_ready(player_name)
def wear_ready(player_name):
  file = open('./Players/' + player_name + '/wearing.txt','r')
  file.close()
  inv_ready(player_name)
def inv_ready(player_name):
  file = open('./Players/' + player_name + '/inventory.txt','r')
  file.close()
  list_ready(player_name)
def list_ready(player_name):
  file = open('./Players/' + player_name + '/treasuryList.txt','r')
  file.close()
  my_player.name = player_name
  file = open('./Players/' + player_name + '/startlocation.txt','r')
  startlocation = file.read()
  file.close()
  if 'Great_Hall' in startlocation:
    run_game(player_name)
  else:
    print_start_location(player_name)
 #tag

def print_start_location(player_name):
  with open('./Players/' + player_name + '/startlocation.txt') as location_line:
    csv_reader = csv.reader(location_line, delimiter= ',')
    line_count = 0
    for row in csv_reader:

      new_start = ('' + (f'{"".join(row)}' + ''))
      line_count += 1

    restart(new_start)
def restart(new_start):
  my_player.location = new_start
  playerlocation = my_player.location.lower()
  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[new_start][DESCRIPTION] + ' ')
  print('' + zonemap[new_start][ITEM] + ' ')
  main_game_loop()

def title_screen_message(message):
  print('\n')
  print('' + message + '\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000            0  0000  0       0          00         0  00000  0        0000000')
  print('000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000')
  print('000 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  000000')
  print('00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000')
  print('00000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  000000')
  print('00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000')
  print('00000000  000000  0000  0       00000  000000         0 000 000 0        0000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

def title_screen_selections():
  choice = input("Command: ")
  while choice.lower() in ['new game','exit','resume']:
    if choice.lower() == ("exit"):
      sys.exit()
    elif choice.lower() == ("new game"):
      setup_game()
    elif choice.lower() == ("resume"):
      get_backpack_contents()
    else:
      title_screen()
      
    while choice.lower() not in ['new game', 'exit','resume']:
      print("Please enter a valid command: New Game - Exit - Resume")
      choice = input("Command: ")
      if choice.lower() == ("exit"):
        sys.exit()
      elif choice.lower() == ("new game"):
        setup_game()
      elif choice.lower() == ("resume"):
        get_backpack_contents()
      else:
        title_screen()

def title_screen():
  os.system('clear')
  print('\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000            0  0000  0       0          00         0  00000  0        0000000')
  print('000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000')
  print('000 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  000000')
  print('00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000')
  print('00000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  000000')
  print('00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000')
  print('00000000  000000  0000  0       00000  000000         0 000 000 0        0000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

# '''
# ##  ##  ##   ## #### ## ## ##
# ###########  ## ########## ##
# ## ##### ##   #  ## ## ##  ##
# ### ### ###  ## #############
# ###########   #            #
# '''

ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
EXIT = 'escape'
DEATH = 'death'
ESCAPE = 'escape'

solved_places = {'Top Left Corner Room':False, 'Lower Left Room':False, 'Top Right Room':False, 'Lower Right Room':False, } # '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                }

#######################################################################################################
#                                                                                                     #
#                                          game CMD handlers                                          #
#######################################################################################################

def print_location():
  playerlocation = my_player.location.lower()
  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
  print('' + zonemap[my_player.location][ITEM] + ' ')
  prompt()

def movement_handler(destination):

  if destination.strip():
    os.system('clear')
    print('\n\n' + 'You enter the ' + destination + '.')
    my_player.location = destination
    print_location() 
  else:
    print('\nSorry...You cannot go that direction.\n')
    my_player.location = my_player.location
    prompt()

def game_over(destination):
  if destination.strip():
    os.system('clear')
    print('\n\n' + 'You enter the ' + destination + '.')
    my_player.location = destination
    print('\n' + my_player.location.upper() + '')
    print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
    print('' + zonemap[my_player.location][EXAMINATION] + ' ')
    my_player.game_over == True
    sys.exit()

def player_look():
  os.system('clear')
  playerlocation = my_player.location.lower()
  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[my_player.location][DESCRIPTION] + '   ')
  print('' + zonemap[my_player.location][ITEM] + ' ')
  prompt()

#######################################################################################################
#                                                                                                     #
#                                          combat and logic for AI                                    #
#######################################################################################################

 ################################################################################
#                                                                                #
#                          OUR VILLAINS                                          #
# ai = bats(Bats, 10, 20, 'Great_Hall', False, ['gold coin'])                    #
# ai = vampire(Vampire, 15, 75, 'Trophy_Room', False, ['sunscreen', 'wand'])     #
# ai = zombie(Zombie, 5, 30, 'Kitchen', False, ['old boots','copper key'])       #
#                                                                                #
 ################################################################################

def ai_intercept(combat_round, my_player, ai, playerlocation):
  playerlocation = ai.location.lower()
  battleground = ai.location.lower()
  playerlocation = my_player.location.lower()
  print("" + str(ai.name.upper()) + " has found you!\n")
  print("The mad beast looks at you for a moment...\n")
  print( "" + str(ai.name.upper()) + " attacks!!!\n")
  combat_state = 1
  hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)

def player_move(myQuarter):
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:
    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:
    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:
    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:
    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:
    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)
  elif destination in ['escape']:
    destination = zonemap[my_player.location][EXIT]
    game_over(destination)
  else:
    print("Where is that?\nYou stay where you are.\n")

#######################################################################################################
#                                                                                                     #
#                                          combat loop basic                                          #
#######################################################################################################

def ai_fight(my_player, ai, battleground, playerlocation):
  combat_round = 0
  combat_state = 1
  combat_round = combat_round
  while combat_state == 1:
    if battleground != playerlocation:
      if combat_state != 0:
        time.sleep(0.02)
        ai_intercept(combat_round, my_player, ai, playerlocation)
      continue
    else:
      combat_state = 1
      hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
    
def hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation):
  combat_state = 1
  combat_round += 1
  playerattack = player.my_player_get_attack()
  playerweapon = player.my_player_get_weapon()
  player_dam_mesg = player.my_player_get_dam_mesg()
  while combat_state == 1:
    if my_player.health > 0:
      if ai.health > 0:
        
        player_dam_math = ((int(playerattack)) * (random.randint(5, 10))) - ((int(ai.attack)) * (random.randint(1, 4)))
        ai_dam_math = ((int(ai.attack)) * (random.randint(4, 9))) - ((int(playerattack)) * (random.randint(2, 3)))
        if int(player_dam_math) < 0:
          print("You should run! The " + ai.name + " is too powerfull!")
          quarter = input("Do you want to fight or run: \n" )
          if quarter.lower() == ('fight'):
            input("Press Enter to Continue")
            hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
           
          elif quarter.lower() == ('run'):
            combat_state = 0
            player_move(quarter.lower(), combat_state)
                   
          else:
            print("Unknown command")
            print("The battle continues.\n")  
            hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
        else:
          if int(ai_dam_math) < 0:
            print("No damage.")
          else:
            my_player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")

########################################################################################################


          ai.health -= abs(player_dam_math)
          if ai.health <= 0:
            combat_state = 0
            loot_state(ai, battleground)
          elif my_player.health <= 0:
            print('What a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0            0  0000  0       0          00         0  00000  0        00000|0\n'+
'000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n'+
'0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n'+
'00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n'+
'0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n'+
'00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n'+
'0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
            sys.exit()
          else:
            mesg = random.randint(0,2)
            dam_mes = player_dam_mesg.pop(int(mesg))
            print("Points of damge you deal: " + str(player_dam_math) + "")
            print("When you " + str(dam_mes) + " with your " + playerweapon + ".")

########################################################################################################

            print("Your health: " + str(my_player.health) + "")
            print("" + ai.name + " health: " + str(ai.health) + "")
            print("Combat round: " + str(combat_round) + "")
            quarter = input("Do you want to fight or run: \n" )
            if quarter.lower() == ('fight'):
              input("Press Enter to Continue")
              hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
           
            elif quarter.lower() == ('run'):
              combat_state = 0
              player_move(quarter.lower())
                   
            else:
              print("Unknown command")
              print("The battle continues.\n")  
              hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
        
      else:
        combat_state = 0
        loot_state(ai, battleground)
    else:  
     
      print('\nWhat a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0            0  0000  0       0          00         0  00000  0        00000|0\n'+
'000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n'+
'0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n'+
'00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n'+
'0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n'+
'00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n'+
'0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
      sys.exit()

  return

def loot_state(ai, battleground):
  print("Victory!\nThe " + ai.name +" has been defeated.")
  t_int = random.randint(0,12)
  reward = ['pocketwatch\n','copper key\n','faded hat\n','old belt\n','wand\n','dirty rags\n','silver earring\n','screwdriver\n','empty candy tin\n','beautiful ring\n','wool socks\n','carved jade dragon\n','small gold coin\n']
  loot = reward.pop(int(t_int))
  ai_death(ai, battleground, loot)

def ai_death(ai, battleground, loot):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    file = open('./Players/' + my_player.name + '/' + battleground + '.txt','r')
    location = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/' + battleground + '.txt','a+')
    file.write(loot)
    file.close()
    prompt()   
  else:
    print("For your effort you gained a " + loot + "")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write(loot)
    file.close
    print("Your health: " + str(my_player.health) + "")
    ai.dead = True
    combat_state = 0
    combat_round = 0
    prompt()
combat_state = 0

#######################################################################################################
#                                                                                                     #
#                                          def for challenges                                         #
#######################################################################################################

def get_green_key():
  
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()

  if 'green key' in my_contents:
    file.close()
    print("You already have this item.\n")
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      print("You get the Green Key from the " + my_player.location + "")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('green key\n')
      file.close()
      prompt()

def examine_bookshelf():
  print("You flip through a few of the books, mostly adventure or detective stories\n a few of them look interesting. All were written a long time ago. Suddenly a big \ngreen key drops onto the floor at your feet.\n")
  cmd = input("Type: 'get key' to pick it up!\n")
  if cmd in ['get key']:
    get_green_key()
  else:
    prompt()

######################################################
#        update player master list                   #                                              ###################################################### 
def move_bronze(new_item):
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_bronze(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()

######################################################
#        check pack + add item                       #                                              ######################################################
def add_bronze(new_item):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    my_player.attack += 5
    print("You take the bronze sword from behind the curtain.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt()

######################################################
#        check redundant item                        #                                              ######################################################
def get_bronze():
  new_item = ('bronze sword')
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_bronze(new_item)

def examine_curtain():
  print("You pull aside the curtain to reveal a bronze short sword.\n")
  cmd = input("Type: 'get sword' to pick it up! ")
  if cmd in ['get sword']:
    get_bronze()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get sword' to pick it up! ")
    if cmd2 in ['get sword']:
      get_bronze()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

                                          #fortune teller app
#######################################################################################################

class Tarotcard(object):
  def __init__(self, name, firstkey, secondkey, danger, fear):
    self.name = name
    self.firstkey = firstkey
    self.secondkey = secondkey
    self.danger = danger
    self.fear = fear

  def __repr__(self):
    return '\nYour card is the {} \nwho guides you with {} and protects you \nfrom {} but beware of this danger: {} \nand rightly fear {}\n'.format(self.name, self.firstkey, self.secondkey, self.danger, self.fear)

my_card1 = Tarotcard('The Fool','capability','empowerment','your own ego','shortcuts')
my_card2 = Tarotcard('The Magician','intuition','initiation','Being aloof','to standoff')
my_card3 = Tarotcard('The High priestess','fertility','nurturing','Overindulging','addiction')
my_card4 = Tarotcard('The Empress','authority','structure','Micromanaging','overt force and order')
my_card5 = Tarotcard('The Emperor','guidance','belief','experience as a misguide','Restricting access to the gods')
my_card6 = Tarotcard('The Hierophant','love','choice','Debilitating prompt()ion','Ill-informed decisions')
my_card7 = Tarotcard('The Lovers','advancement','success','Resting on laurels','impulsive behavior')
my_card8 = Tarotcard('The Chariot','discipline','vitality','Indulgence','the sick bed')
my_card9 = Tarotcard('Strength','solitude','withdrawal','angst','hiding power')
my_card10 = Tarotcard('The Hermit','luck','revolution','gambling','fighting Nature')
my_card11 = Tarotcard('The Wheel','balance','objectivity','criticism','favoritism')
my_card12 = Tarotcard('Justice','enlightenment','reversals','yielding','laying blame')
my_card13 = Tarotcard('The Hanged Man','ending','departure','fatalism','rumination')
my_card14 = Tarotcard('Death','blending','harmony','zealotry','treachery')
my_card15 = Tarotcard('Temperance','shadow','delusion','materialism','manifest posession')
my_card16 = Tarotcard('The Devil','demolition','destruction','anachronsim','Malicious destruction')
my_card17 = Tarotcard('The Tower','hope','truth','Denial','locum lacuna')
my_card18 = Tarotcard('The Star','mystery','uncertainty','fantasy','melancholy')
my_card19 = Tarotcard('The Moon','joy','energy','delusion','boastfulness')
my_card20 = Tarotcard('The Sun','revival','invitation','inversion','disinclimant self')
my_card21 = Tarotcard('Judgement','wholeness','fullness','malice','malaise')
my_card22 = Tarotcard('The World','desire','invention','Indolence','cowardice')

#####################################itterator#for#dictionary##################################

def future_card(for_future):

  fort2 = random.randint(0,19)
  card = for_future.pop(int(fort2))
  print("\nNow I am looking at your future, prepare yourself....")
  data = eval(card)
  print("" + str(data) + "")
  input("\nWhen you are ready press enter\n")
  print("The fortune teller faints from her efforts.\n")
  prompt()

def present_card(for_present):

  fort1 = random.randint(0,20)
  card = for_present.pop(int(fort1))
  print("\nNow I see your present, today even this moment....")
  data = eval(card)
  print("" + str(data) + "")

  for_future = for_present
  input("\nWhen you are ready press enter\n")
  future_card(for_future)

def past_card():
  for_past = ['my_card1','my_card2','my_card3','my_card4','my_card5','my_card6','my_card7','my_card8','my_card9','my_card10','my_card11','my_card12','my_card13','my_card14','my_card15','my_card16','my_card17','my_card18','my_card19','my_card20','my_card21','my_card22']

  fort = random.randint(0,21)
  card = for_past.pop(int(fort))
  print("\nI will look into your past....")
  data = eval(card)
  print("" + str(data) + "")

  for_present = for_past
  input("\nWhen you are ready press enter\n")
  present_card(for_present)

#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                                challenge defs cont.                                 #
#######################################################################################################

def hear_fortune():
  print("'Place your hand on the deck...\n'")
  print("She seems dizzy, 'I see now and I see then...I see what will be...'\n")
  input("\n<<When you are ready hear your fortune press enter>>\n\n")
  past_card()

def escape():
  destination = zonemap[my_player.location][EXIT]
  game_over(destination)


def run_from_fortuneteller():

  print("The fortune teller screams: 'No one runs from me!\n")

  my_player = player()
  ai = zombie()
  whereabouts = my_player.location.lower()
  battleground = ai.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  ai_fight(my_player, ai, battleground, playerlocation)

def fix_clock():
  global clock
  clock = 0
  print("\n\nYou open the big glass door and start messing with the inside of the \nOld Bavarian Clock. You feel like you know what you are doing.\nDo you have a screwdriver?\n")
  cmd = input("Yes or No.\n")
  if cmd in ['yes']:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    screwdriver_search = file.read()
    if 'screwdriver' not in screwdriver_search:
      file.close()
      print("You do not have a screwdriver.\n")
      prompt()
    else:
      print("You carefully pull out a large sprocket and very long chain falls out \nonto the floor, luckily it did not fall out all of the way.\n")
      print("Do you have nuts and bolts?\n")
      n_cmd = input("Yes or No.\n")
      if n_cmd in ['yes']:
        file = open('./Players/' + my_player.name + '/inventory.txt','r')
        bolt_search = file.read()
        if 'nuts and bolts' not in bolt_search:
          file.close()
          print("You do not have nuts and bolts.\n")
          prompt()
        else:
          print("You notice another chain, one with a hole that matches the do-dad on \nthe chain you just pulled out.\n\nYou connect the two with two nuts and a bolt.\nJust then the cockoo pops out:\nCooKoo! CooKoo!\nAnd the clock winds itself up, pulling the chain from the floor.\n\nBong! Bong!\nIt must be two o'clock.\n")
          clock += 1
      else:
        prompt()
  else:
    prompt()    

def get_cloak():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'cloak' in my_contents:
    file.close()
    print("You already have one of these.\n")
    prompt()
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      file.close()
      my_player.attack += 5
      print("You take the heavy black cloak.\n")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('cloak\n')
      file.close
      prompt()

def examine_statue():
  print("Hanging over the statue's shoulders is a heavy cloak. It looks like \n" +
"great protection and a lot flashier than anything anybody at school will ever \n" +
"have.\n")
  cmd = input("Type: 'get cloak' to pick it up! ")
  if cmd in ['get cloak']:
    get_cloak()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get cloak' to pick it up! ")
    if cmd2 in ['get cloak']:
      get_sword()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

def investigate_lump():
  print("You cautiosly approach the lump in the center of the room. It is so like \n" +
"like the shape and size of a person you expect it to wake up, or at least \n" +
"breathe. But it does nothing. It just lies there. \n" +
"Since when was there a REAL haunted house in THIS neighborhood?\n" +
"It is too scary, you have to back away!\n")
  time.sleep(0.05)
  vampire_attack()

def vampire_attack():
  print("Someone is behind you!\n")
  my_player = player()
  ai = vampire()
  whereabouts = my_player.location.lower()
  battleground = ai.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  ai_fight(my_player, ai, battleground, playerlocation)

def tinkling_bells():
  prompt()


def hide_from_the_gardener():

  cmd_x = input("You duck down to avoid the gardener. Who knew there would be anyone here?\nJust then you notice a door leading out into the back of the property.\nDo you want to try opening the Kitchen Door?\nYes or No.\n")
  if cmd_x in ['yes','Yes']:
    print("Grr....\nIt is locked.\n")
    cmd_s = input("Do you have the steel keys? Yes or No.\n")
    if cmd_s in ['yes','Yes','I do','I have the steel keys','yes I have the steel keys','Yes I have the steel keys']:

      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      my_stuff = file.read()

      if 'steel keys' in my_stuff:
        file.close()    
        cmd_k = input("The door to the back of the property is open!\nBetter safe than sorry, Type: 'sneak into garden' to leave the Kitchen.\n")
        if cmd_k in ['sneak into garden','I sneak into garden','sneak into the garden']:
          ##########################################################
          os.system('clear')
          my_player.location = 'Kitchen_Door'
          print_location()
          ##########################################################
        else:
          prompt()
      else:
        print("You do not have the steel keys.\n")
        file.close()
    else:
      prompt()
  else:
    prompt()

def get_coins():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    print("You take the silver coins.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('thirty silver coins\n')
    file.close
    prompt()
  

def open_wooden_box():
  print("The small wooden box opens slowly on rusty hinges.\nInside are a couple dozen silver coins!")
  cmd = input("Type: 'get coins' you can get rich like this! ")
  if cmd in ['get coins']:
    get_coins()

#######################################################################################################
#                                                                                                     #
#                                               trap specific content                                 #
#######################################################################################################

def squish_spider():

  thrownout = "Just as you lift your foot to squish the tarantula spider a door you did not \n"
  thrownout1 = "at first notice flies open. The gardener stomps in. He shouts: 'I knew I heard \n"
  thrownout2 = "something going on in here! You better not ever come back to this house!' \n"
  thrownout3 = "He deposits you on the curb.\n"

  thrownout4 = "This house is Off-Limits!\nGAME OVER\n"
  thrownout5 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout6 = "0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n"
  thrownout7 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  thrownout8 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout9 = "0|0            0  0000  0       0          00         0  00000  0        00000|0\n"
  thrownout10 = "000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n"
  thrownout11 = "0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n"
  thrownout12 = "00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n"
  thrownout13 = "0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n"
  thrownout14 = "00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n"
  thrownout15 = "0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n"
  thrownout16 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout17 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  thrownout18 = "0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n"
  thrownout19 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout20 = "\n\n\n\nYou go on ahead, we will wait right here...\n"

  for character in thrownout:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout1:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout3:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout7:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout8:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout9:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout10:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout11:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout12:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout13:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout14:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout15:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout16:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout17:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout18:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout19:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout20:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
    sys.exit()

#######################################################################################################
#                                                                                                     #                                                   upstair hallway
#                                               module specific challenges                            #
#######################################################################################################

def move_keys(new_item):
  
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read()
  
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()

    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')

    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close()
    
    add_keys(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()

def add_keys(new_item):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Keys are hanging there, but your backpack is full.")
    prompt()   
  else:
    print("You take the keys from behind the hideous painting.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt() 

def take_keys():
  new_item = ('steel keys')
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_keys(new_item)

def examine_painting():
  print("\nWhat an ugly wierd, somehow adorable thing?\nThis place is getting into your head. Is it hanging crooked?\n")

  cmd = input("Do you want to straighten the painting?\n")
  ans = ['yes','I will','straighten the painting','okay','sure','I straighten the painting']

  if cmd in ans:
    print("\nThe painting wobbles then hangs straight.\nWhat is this? Is something behind the painting?")
    new_cmd = input("Do you want to check behind the painting?\n")
    decs = ['yes','I will','okay','sure']

    if new_cmd in decs:
      print("Two small steel keys are hanging behind the painting.\n")
      xmd = input("Type: 'take the keys': ")
      control = ['take the keys']
      if xmd.lower() in control:
        take_keys()
      else:
        print("prompt1\n")
        prompt()
    else:
      prompt()
      print("prompt2\n")
  else:
    prompt()
    print("prompt3\n")     


def ivan_turn():
  print("\nOh my! There is a spook behind you!!!\n")
  my_player = player()
  ai = ghost()
  whereabouts = my_player.location.lower()
  battleground = ai.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  ai_fight(my_player, ai, battleground, playerlocation)

def no_ghosts():
  print("You plug your ears and shut your eyes...\n\nNo such thing as ghosts! No such thing as ghosts!\nA little self talk should help.\n")
  prompt()

################################################################################################

def examine_painting_1():
  print("\nYes, you can confirm that the painting is now certainly \nfrowning or is that a grin?\n")
  prompt()      

def ivan_turn_1():
  print("\nIf someone was behind you at least you would have someone to talk too.\n")
  prompt()

def no_ghosts_1():
  print("At this point, this is no help at all. Maybe it is time to think \nreally really hard.\n")
  prompt()


################################################################################################

def examine_floor():
  print("\nSqueak and wobble, you follow it around and around.\n")
  prompt() 

def check_bookcase():
  prompt()

def jump_on_bed():
  print("You climb up onto the bed...\n\nYou are surprise by a very large bat!\nEeek! Eeek! Eeek!\nIt looks mad!")
  my_player = player()
  ai = bat()
  whereabouts = my_player.location.lower()
  battleground = ai.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  ai_fight(my_player, ai, battleground, playerlocation)

def look_out_window():
  prompt()
def search_items():
  print("Searching...\n\nThe people who lived here saved almost everything. In the clutter loosely \norganized around their mattress they left everything from torn magazine covers \nto a toilet brush.\n")
  cmd = input("If there is something specific you need just type in now: \n")

  if cmd in ('nuts and bolts','comb','toilet brush','shoe horn','reading glasses','golfer pencil','rain jacket','makeup tin','jump rope'):
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("You might have seen one, but your backpack is full.")
      prompt()   
    else:
      found_item(cmd)
  else:
    print("You don't find a " + str(cmd) + " in all the mess of things.\n")
    prompt()

def found_item(cmd):

######################################################
#        update player master list                   #                                              ###################################################### 

  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if cmd in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(cmd) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_found_item(cmd)
  else:
    print("Something maybe amiss with your file structure.\nDo you already have a " + str(cmd) + "?\n")
    file.close()
    prompt()

def add_found_item(cmd):
  print("What luck! You find a " + str(cmd) + "!\n")
  file = open('./Players/' + my_player.name + '/inventory.txt','a+')
  file.write('' + str(cmd) + '\n')
  file.close
  prompt()

def move_mattress():
  print("Huff...Puff...Grr...\n\nYou struggle with the giant feather bed as long as you can. But it is no use. \nIt just won't budge.\n\n")
  prompt()

#######################################

def read_book():
  if clock == 1:
    print("Reading...\nAs you struggle to find the begining of a chapter or some reference \npoint a letter falls from the pages of the book, falling open.\nThis is what it says:\n\n" + my_player.name + ",\nI have long feared that we might never meet, and those fears are realized.\nTrust no one " + my_player.name + ", enemies are many and the danger is great. \nWith that danger comes great reward, " + my_player.name + ", a reward I thought we \nwould share together, sadly my time is near its end.\nBe sure you have visited the garage before you enjoin this next \npart of your journey and know that there are four doors ahead of you. \nFour locked doors which require four special keys.\nDo not proceed without those four special keys!\n\nsigned: Einar Einen\n\n")
    prompt()
  else:
    print("A most curious book full of robots and vegetables riding around in outerspace!\n")

def add_crystal(new_item):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    print("The crystal looks useful. You take it from the desk drawer.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt()

def move_crystal(new_item): 
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read()
  
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()

    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')

    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close()
    
    add_crystal(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()  

def get_crystal():
  new_item = ('crystal')
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_crystal(new_item)

def search_desk():
  print("Looks like a challenge...\n\nYou paw through the contents of the desk looking for anything that isn't broken \nor so caked with dirt you can't guess what it is supposed to be at all. \nWhat's this! A great big piece of quartz! And how weirdly it is wrapped with on one end \nwith copper wire. Very strange...\n")
  cmd = input("Type: 'get crystal' to pick it up\n")

  if cmd in ('get crystal'):
    get_crystal()
  else:
    prompt()

def other_books():
  if clock == 1:
    enter_catacomb()
  else:
    print("The other books are just as wild as the book on the desk appears to be.\nYou could spend hours here with all these strange books and really no learn\nanything! The drawings are just too strange!\n")

def enter_catacomb():
  print("Grr....\nWith a supreme effort you drag one of the books away from the wall to find \na keyhole in the floor!")
  cmd = input("Do you have the steel keys?\nYes or No.\n")
  if cmd in ['yes','Yes','I do','I have the steel keys','yes I have the steel keys','Yes I have the steel keys']:

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    my_stuff = file.read()

    if 'steel keys' in my_stuff:
     
      print("With a burst of enery you shove the other two books aside!")
      file.close()
      cmd_1 = input("Do you want to see what you will find if you twist the key???\nYes or No.\n")
      if cmd_1 in ['yes','sure','okay']:
        cmd_2 = input("You find a hidden stairway!\nDo you have the electric torch?\nYes or No.\n")
        if cmd_2 in ['yes','i do','i sure do']:
          file = open('./Players/' + my_player.name + '/inventory.txt','r')
          my_stuff = file.read()
          if 'electric torch' in my_stuff:

            file.close()

            ans = input("Are you ready for the next part of your adventure?\nYes or No.\n")
            if ans in ['yes']:
              print("You descend the darkened stairway.\n")

              my_player.location = 'Darkened_Stairway'
              print_location()

            elif ans in ['no']:
              print("You will find the next part of your adventure here when you are ready.\n")
              prompt()
            else:
              print("Print a clear yes or no, please.\n")
              ans = input("Are you ready for the next part of your adventure?\nYes or No.\n")
              if ans in ['yes']:
                os.system('clear')
                print("You descend the darkened stairway.\n")

                my_player.location = 'Darkened_Stairway'
                print_location()

              else:
                prompt()
          else:
            print("\nYou do not have the electric torch.\nIt is much too dark down there for you to enter.\n")
            file.close()
          
            
        else:
          prompt()    
      else:
        prompt()
    else:
      print("You do not have the steel keys.\nIf you are sure you do have the steel keys just restart.\n")                       
      file.close()
      prompt()                   
  else:
    prompt()

def check_clothes():
  print("Hmm...\n\nThey never have anything in your size.\n")
  prompt()

def get_junk():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    junk = ['hat pin\n','locket\n','flashligh\n','mittens\n','emerald\n']
    file.write(str(junk))
    file.close
    prompt()

def open_cabinets():
  print("You climb...\n\nAbove the racks of clothing are a few interesting items which you might use \nor at least trade to a friend.\n")
  cmd = input("Type: 'get junk' to take these interesting things.\n")
  if cmd in ['get junk']:
    get_junk()
  else:
    prompt()

def tiny_chair():
  print("\nHow silly this little chair is you must have thought, before you bumped \ninto a loose loose panel in the wall. \n\nYou find a hidden room!\nType: 'move' \nand then type: 'west' to enter this secret room.\n\n")
  prompt()

def listen():
  print("Listening...\n\nIt is a good thing you took a moment to listen you can definetaly hear the \nticking of the clock and also steady shuffling feet. \nSomeone else is here.\n\n")
  prompt()

def examine_carpet():
  print("Hmm, if this was the Guggenheim...\n\nYou pause to try to admire the ghastly choice in floor covering. \nThe reds and golds wind together like snakes.\n\n")
  prompt()

def rescue_plant():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    print("\nYou rescue a dying flower from the upstairs hallway.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('potted plant\n')
    file.close()
    prompt()

def turn_back():
  print('This is getting ever more weird.\nIt is probably best to think about your future.\nThink about having a future at all!\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0            0  0000  0       0          00         0  00000  0        00000|0\n'+
'000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n'+
'0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n'+
'00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n'+
'0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n'+
'00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n'+
'0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
  sys.exit()

#bottom of chute
def guess_answer():
  riddle_ans = input("Go ahead and take your best guess: ")
  riddle_correct = ['record player','recordplayer','turn table','turntable','phonograph']
  if riddle_ans in riddle_correct:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    my_stuff = file.read()
    if 'copper key' in my_stuff:
      file.close()

      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      key_lines = file.readlines()
      
      new_file = open('./Players/' + my_player.name + '/inventory.txt','w')

      for key_line in key_lines:
        if key_line != ('copper key\n'):
          new_file.write(key_line)
          continue
        continue
      file.close()
      new_file.close()

      print("The copper key bursts into flames. In a moment it is gone.\n")

      my_player.location = 'Library'
      print_location()
    else:
      print("\nThe ugly door laughs. It shouts at you: You can guess my riddle but without my \nkey you won't go anywhere! Ha Ha Ha Ha Ha!\n\nIt seems you lack the copper key...\n")
      input("\nPress Enter to continue...\n")
      print_location()
  else:
    print("Noooooooo...try again...\n")
    print_location()

def guess_answer_mod():
  guess_answer()

def need_hint():
  print("A hint? I can't recall when I started giving hints.\nOh well if it will keep you happy here is a hint: \nWhat is one third of one hundred?\n")
  guess_answer()

def new_riddle():
  new_riddle = input("Do you want... \n1.) A hat riddle? \n2.) A tree riddle ...or... \n3.) A shoe riddle?\n\nChoose 1, 2 or 3...\n")
  if '1' in new_riddle:
    if new_riddle != ('2'):
      if new_riddle != ('3'):
        print("No hints...\n\nWhat will you never get out of a felt hat?\n")

        riddle1_ans = input("Go ahead and take your best guess: ")
        riddle1_correct = ['a stain','stain']
        if riddle1_ans in riddle1_correct:
          file = open('./Players/' + my_player.name + '/inventory.txt','r')
          my_stuff = file.read()
          if 'copper key' in my_stuff:
            file.close()

            file = open('./Players/' + my_player.name + '/inventory.txt','r')
            key_lines = file.readlines()
      
            new_file = open('./Players/' + my_player.name + '/inventory.txt','w')

            for key_line in key_lines:
              if key_line != ('copper key\n'):
                new_file.write(key_line)
                continue
              continue
            file.close()
            new_file.close()

            print("The copper key bursts into flames. In a moment it is gone.\n")

            my_player.location = 'Library'
            print_location()
          else:
            print("\nThe ugly door laughs. It shouts at you: You can guess my riddle but without my \nkey you won't go anywhere! Ha Ha Ha Ha Ha!\n\nIt seems you lack the copper key...\n")
            input("\nPress Enter to continue...\n")
            print_location()
        else:
          print("Noooooooo...try again...\n")
          print_location()
      else:
        print("Are you trying to cheat?\n")
        print_location()     
    else:
      print("Are you trying to cheat?\n")
      print_location()            

  elif '2' in new_riddle:
    if new_riddle != ('1'):
      if new_riddle != ('3'):
        print("No hints...\n\nFigs don't fall from me, but sometimes little bears do...what am I?\n")

        riddle2_ans = input("Go ahead and take your best guess: ")
        riddle2_correct = ['eucalyptus','eucalyptus tree','a eucalyptus tree']
        if riddle2_ans in riddle2_correct:
          file = open('./Players/' + my_player.name + '/inventory.txt','r')
          my_stuff = file.read()
          if 'copper key' in my_stuff:
            file.close()

            file = open('./Players/' + my_player.name + '/inventory.txt','r')
            key_lines = file.readlines()
      
            new_file = open('./Players/' + my_player.name + '/inventory.txt','w')

            for key_line in key_lines:
              if key_line != ('copper key\n'):
                new_file.write(key_line)
                continue
              continue
            file.close()
            new_file.close()

            print("The copper key bursts into flames. In a moment it is gone.\n")

            my_player.location = 'Library'
            print_location()
          else:
            print("\nThe ugly door laughs. It shouts at you: You can guess my riddle but without my \nkey you won't go anywhere! Ha Ha Ha Ha Ha!\n\nIt seems you lack the copper key...\n")
            input("\nPress Enter to continue...\n")
            print_location()
        else:
          print("Noooooooo...try again...\n")
          print_location()
      else:
        print("Are you trying to cheat?\n")
        print_location()     
    else:
      print("Are you trying to cheat?\n")
      print_location()            

  elif '3' in new_riddle:
    if new_riddle != ('2'):
      if new_riddle != ('1'):
        print("No hints...\n\nYou don't get the Capitol of Arkansas in your shoe, what do you get?\n")

        riddle3_ans = input("Go ahead and take your best guess: ")
        riddle3_correct = ['little rock','a little rock']
        if riddle3_ans in riddle3_correct:
          file = open('./Players/' + my_player.name + '/inventory.txt','r')
          my_stuff = file.read()
          if 'copper key' in my_stuff:
            file.close()

            file = open('./Players/' + my_player.name + '/inventory.txt','r')
            key_lines = file.readlines()
  
            new_file = open('./Players/' + my_player.name + '/inventory.txt','w')

            for key_line in key_lines:
              if key_line != ('copper key\n'):
                new_file.write(key_line)
                continue
              continue
            file.close()
            new_file.close()

            print("The copper key bursts into flames. In a moment it is gone.\n")

            my_player.location = 'Library'
            print_location()
          else:
            print("\nThe ugly door laughs. It shouts at you: You can guess my riddle but without my \nkey you won't go anywhere! Ha Ha Ha Ha Ha!\n\nIt seems you lack the copper key...\n")
            input("\nPress Enter to continue...\n")
            print_location()
        else:
          print("Noooooooo...try again...\n")
          prompt()
      else:
        print("Are you trying to cheat?\n")
        prompt()     
    else:
      print("Are you trying to cheat?\n")
      prompt()            
  else:
    print("Pick 1 2 or 3.\n")
    print_location()

#water_fountain
def investigate_carvings():
  print("\n")
  prompt()
def try_green_key():

  print("\n")
  prompt()


def read_note():
  print("You read the note assuming it is a magic spell but nothing happens...\nat first. You wait only a moment or two before snow bursts from the fountain.\nIt is over in only a few seconds. Then the water fountain only splashes water over its carvings.\n")
  prompt()

#library

def get_first_note_page():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'red note' in my_contents:
    file.close()
    print("You already have one of these.\n")
    prompt()
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('red note\n')
      file.close()
      prompt()

def first_note_page():
  print("Very strange drawings are on this red note.\n")
  cmd = input("Type: 'get red note' to pick it up! ")
  if cmd in ['get red note']:
    get_first_note_page()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get red note' to pick it up! ")
    if cmd2 in ['get red note']:
      get_first_note_page()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

def get_second_note_page():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'blue note' in my_contents:
    file.close()
    print("You already have one of these.\n")
    prompt()
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('blue note\n')
      file.close()
      prompt()

def second_note_page():
  print("Very strange drawings are on this blue note.\n")
  cmd = input("Type: 'get blue note' to pick it up! ")
  if cmd in ['get blue note']:
    get_second_note_page()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get blue note' to pick it up! ")
    if cmd2 in ['get blue note']:
      get_second_note_page()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

def get_third_note_page():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'green note' in my_contents:
    file.close()
    print("You already have one of these.\n")
    prompt()
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('green note\n')
      file.close()
      prompt()

def third_note_page():
  print("Very strange drawings are on this green note.\n")
  cmd = input("Type: 'get green note' to pick it up! ")
  if cmd in ['get green note']:
    get_third_note_page()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get green note' to pick it up! ")
    if cmd2 in ['get green note']:
      get_third_note_page()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

#room_of_faces
def turn_star():
  pass
def try_fourth_key():
  print("You twist the key but the door does not open.\n")
  prompt()
def read_the_note():
  print("A wind rises up in the vaults below the mansion.\n")
  prompt()

#faded_tapestries
def examine_tapestries():
  print("What strange ideas someone had not to mention enough time to stitch all \nthese tapestries together. Any real meaning is hard to define. Most of the tapestries show people\ndancing and a few show fires and stars. For some reason all the people are stitched with red threads \nwhile only a few are blue or green. There are no buildings or towns \nonly stitch-work people dancing around.\n")
def search_for_escape_route():
  print("The sound of people yelling is clear...it sounds like a soccer game\nand you are near the school...it is just so dark. Even the brilliant beam of the electric torch\ndoes not help much...you dig in the loose earth and find something...another keyhole.\nThis looks like no door you've ever seen...\n")
  keyhole = input("Do you want to try one of the remaining keys?\n")
  key_ans = ['yes','i will','okay']
  if keyhole.lower() in key_ans:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    my_stuff = file.read()
    if 'turquose key' in my_stuff:
      file.close()
      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      key_lines = file.readlines()
      new_file = open('./Players/' + my_player.name + '/inventory.txt','w')
      for key_line in key_lines:
        if key_line != ('turquoise key\n'):
          new_file.write(key_line)
          continue
        continue
      file.close()
      new_file.close()
      bigscare = "The only key that will fit this odd lock is the turquoise key from\n"
      bigscare2 = "the graveyard. Just as you stick the turquoise key into the key hole a\n"
      bigscare3 = "huge gray hand reaches out of the mud grabbing you by the arm. It\n"
      bigscare4 = "pulls you up through the mud leaving you beside the fallen tree!\n"
      bigscare5 = "How about a heart attack before dinner?\n"

      for character in bigscare:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

      for character in bigscare2:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

      for character in bigscare3:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

      for character in bigscare4:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

      for character in bigscare5:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

      my_player.location = 'Graveyard'
      print_location()

def try_green_key():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'green key' in my_contents:
    file.close()
    print("You twist the key inside the lock. The door opens.\n")
    my_player.location = 'Singing_Crystals'
    print_location()
  else:
    print("This is not the correct key.\n")
    file.close
    prompt()

#singing_crystals
def first_clue():
  pass
def second_clue():
  pass
def third_clue():
  pass

#stairway_and_candles
def light_a_candle():
  print("Just to think of lighting a candle causes one of the candles to burn.\n")
  prompt()
def blow_a_candle_out():
  print("You bend down to blow a candle out but a powerful wind whips through \nthe room, coming from somewhere. It swirls through the room and blows \ndown the hall.\nThe candles stay lit.\n")
  prompt()
def read_the_note():
  print("Thunder booms in the underground caves below the mansion. The candles \nsputter but return to their bright constant glow. The note turns to dust in your hands.\n")
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  invs = file.readlines()
  note_success = open('./Players/' + my_player.name + '/inventory.txt','w+')
  for inv in invs:
    if inv != 'note':
      note_success.write(inv)
      continue
    continue
  file.close()
  note_success.close()
  file = open('./Players/' + my_player.name + '/wearing.txt','a+')
  file.write('pendant of philemon\n')
  player.magic += 2
  file.close()
#inner_chamber
def turn_the_star():
  mega = input("The outer star has nine pips.\nChoose 1 - 9: ")
  if mega in ('1','2','3','4','5','6','7','8','9'):
    print("The middle star starts to spin.")
    turn_middle_star()
  else:
    print("Try again.\n")
    prompt()
def turn_middle_star():
  mext = input("The outer star has nine pips.\nChoose 1 - 9: ")
  if mext in ('1','2','3','4','5','6','7','8','9'):
    print("The inner star starts to spin.")
    turn_inner_star()
  else:
    print("Try again.\n")
    prompt()
def turn_inner_star():
  mojo = input("The outer star has nine pips.\nChoose 1 - 9: ")
  if mojo in ('1','2','3','4','5','6','7','8','9'):
    effect = (((int(mega) * 10) - int(mext)) / 90 ) * (((int(mext) * 10) - int(mojo)) * 90) * (((int(mojo) * 10) - int(mega)) + 90)
    print(effect)
    input("\nHit Enter to Continue")
  else:
    print("Try again.\n")
    prompt()

###########################GARDEN#DEFS#########################################

def get_quest_item():
  note = 0
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()

  if 'red note' in my_contents:
    note += 1

  if 'blue note' in my_contents:
    note += 1

  if 'green note' in my_contents:
    note += 1

  if 'white note' in my_contents:
    file.close()
    if note == 3:
      print("The strange notes all fit together! Words appear where only scratches \nand strange symbols had been!\nIt looks like a magic spell! What will it do?\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    items = file.readlines()
    full_note = open('./Players/' + my_player.name + '/inventory.txt','w')
    for item in items:
      if item != 'red note':
        if item != 'blue note':
          if item != 'green note':
            if item != 'white note':
              full_note.write(item)
              continue
            continue
          continue
        continue
      file.close()
      full_note.close()
      file = open('./Players/' + my_player.name + '/inventory.txt','a')
      file.write('note\n')
      prompt()
    else:
      print("You already have one of these.\n")
      prompt()
  else:
    note = 0
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      print("You take the white note that was hidden in the graveyard.\n")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('white note\n')
      file.close()
      prompt()

def read_tombstone():
  print("The words are too chipped to read. \nSomeone surely lived a long time ago. In this very house, do you suppose?\nWhat is this...a scrap of paper with strange symbols...\n")
  cmd = input("Type: 'get white note' to pick it up! \n")
  if cmd in ['get white note']:
    get_quest_item()
  elif cmd in ['go back']:
    prompt()
  else:
    cmd2 = input("Try again, Exactly: 'get white note' to pick it up!\n")
    if cmd2 in ['get white note']:
      get_quest_item()
    elif cmd2 in ['go back']:
      prompt()
    else:
      print("You will get it next time")
      prompt()

def watch_for_gardener():
         #######################################################################8########
  print("You see the gardener trudging along pushing a brush mower along the tree line.\n" +
"The property of the mansion extends almost a football field size patch to the \n" +
"north. He has been out cutting grass all day. The sun is sinking. It is a big \n" +
"red ball in the west already.\n")
  prompt()

def get_turquoise_key():
  
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()

  if 'turquoise key' in my_contents:
    file.close()
    print("You already have this item.\n")
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      print("You get the Turquoise Key from the " + my_player.location + "")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('turquoise key\n')
      file.close()
      prompt()

def examine_pile_stones():
  print("A group of stones are gathered near the fallen tree. The stones are brown \n" +
"or gray and oblong so that they look a bit tipsy on their round \n" +
"bottoms. They are crowded around something glittering in the sun,\n" +
"another key! This one made of turquoise!\n")
  cmd = input("Type: 'get key' to pick it up!\n")
  if cmd in ['get key']:
    get_turquoise_key()
  else:
    prompt()

def examine_hose():
  print("Drip, drip, drip there is water running through the hose. Maybe the gardener \nhas another garden behind the shed.\n")
  prompt()

def fix_bench():
  print("You can pull on one end, but the other sags. You can lifts that end...but the \nfar end always twist, falling off its already wobbly legs.\n")
  prompt()

def examine_flowerpots():
  print("The flowerpots are in good shape and the flowers have large bursts of blossoms.\n")
  prompt()

def examine_lawnmower():
  print("This one doesn't run, obviously. The gardener is cutting the grass right now.\nWhat a mess of grass, dirt, grease, and gunk!\n")
  prompt()

def search_workbench():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  mine = file.read()
  if 'crystal' in mine:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    mine2 = file.read()

    if 'flashlight' in mine2:
      file.close()

      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      backpack_len = file.readlines()
      length = len(backpack_len)
      file.close()
      if length > 15:
        print("What a huge load of stuff. You could build a go-cart easily, but your \nbackpack is full.")
        prompt()   
      else:
        file = open('./Players/' + my_player.name + '/inventory.txt','a+')
        file.write('electric torch\n')
        file.close()
    

        file = open('./Players/' + my_player.name + '/inventory.txt','r')
        my_stuffs = file.readlines()

        torch_file = open('./Players/' + my_player.name + '/inventory.txt','w')
        for my_stuff in my_stuffs:
          if my_stuff != ('crystal\n'):
            torch_file.write(my_stuff)
            continue
          continue
        file.close()
        torch_file.close()

        file = open('./Players/' + my_player.name + '/inventory.txt','r')
        my2_stuffs = file.readlines()

        torch2_file = open('./Players/' + my_player.name + '/inventory.txt','w')

        for my2_stuff in my2_stuffs:
          if my2_stuff != ('flashlight\n'):
            torch2_file.write(my2_stuff)
            continue
          continue
        
        file.close()
        torch2_file.close()

        print("Holy cow! You see the strange battery and suddenly figure out why the flashlight \nyou found does not work. It is an electric torch! People used this type light a\nlong time ago. You snap the flashlight to the battery and twist the crystal into\nthe threadings in the silver cup and Ta Da!\nYou have the electric Torch!\n")
        prompt()
    else:
      print("You sift through all the tools and junk on the table. Obviously the gardener \nuses these things. Taking any of these tools would be stealing.\n")
      file.close()
      prompt()
  else:
    print("What a huge load of stuff. You could build a go-cart easily!\n")
    file.close()
    prompt()

def examine_gears():
  print("At the bottom of a steel rack are dozens of brass gears stacked up. Many of\nthem are quite thick. They are just a bit greasy. The teeth are worn. Odd, that...\nMost of them are too heavy to lift. What are these gears used for?\n")
  prompt()

def catch_grasshopper():
  print("So many grasshoppers are here munching on grass and leaves where the shade \nof the gardeners shed keeps the air cool. It seems like an easy task. You grab and \ngrab but they just leap away. This is maybe the best summer ever!\n")
  prompt()

def sneak_around_shed():
  dinnertime = "You sneak around the shed on fresh cut grass wondering where the gardener might\n"
  dinnertime2 = "be. Sure enough on the other side of the shed he is cutting back around!\n"

  dinnertime4 = "You decide to run while you have a chance!\n"
  dinnertime5 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  dinnertime6 = "0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n"
  dinnertime7 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  dinnertime8 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  dinnertime9 = "0|0            0  0000  0       0          00         0  00000  0        00000|0\n"
  dinnertime10 = "000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n"
  dinnertime11 = "0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n"
  dinnertime12 = "00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n"
  dinnertime13 = "0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n"
  dinnertime14 = "00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n"
  dinnertime15 = "0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n"
  dinnertime16 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  dinnertime17 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  dinnertime18 = "0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n"
  dinnertime19 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  dinnertime20 = "\n\n\n\nYou go on ahead, we will wait right here...\n"

  for character in dinnertime:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)

  for character in dinnertime2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)

  for character in dinnertime4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime7:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime8:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime9:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime10:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime11:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime12:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in dinnertime13:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in dinnertime14:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime15:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime16:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime17:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime18:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime19:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in dinnertime20:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
    sys.exit()

def gather_sunflower_seeds():

  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    print("You gather a big handfull of sunflower seeds and eat a few too. Each \nsunflower must produce thousands of them! There is no end!\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('sunflower seeds\n')
    file.close()
    prompt()

def squish_tomatoes():
  thrownout = "Just as you lift your foot to squish your first tomato. The gardener stops you.\n"
  thrownout2 = "He shouts: 'I knew it! You kids are squishing my tomatoes!\n"

  thrownout4 = "This house is Off-Limits!\nGAME OVER\n"
  thrownout5 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout6 = "0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n"
  thrownout7 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  thrownout8 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout9 = "0|0            0  0000  0       0          00         0  00000  0        00000|0\n"
  thrownout10 = "000 0000  0000 0  0000  0 00000 0 000  000 00 0000000 0   000   0 000000  000000\n"
  thrownout11 = "0|0 0000  0000 0  0000  0 0000000 000  000 00 0000000 0 0 000 0 0 000000  0000|0\n"
  thrownout12 = "00000000  000000  0000  0    00000000  000000 0000000 0 00 0 00 0       00000000\n"
  thrownout13 = "0|000000  000000        0 00000000000  000000 0000000 0 00 0 00 0 000000  0000|0\n"
  thrownout14 = "00000000  000000  0000  0 00000 00000  000000 0000000 0 00   00 0 000000  000000\n"
  thrownout15 = "0|000000  000000  0000  0       00000  000000         0 000 000 0        00000|0\n"
  thrownout16 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout17 = "0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n"
  thrownout18 = "0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n"
  thrownout19 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000\n"
  thrownout20 = "\n\n\n\nYou go on ahead, we will wait right here...\n"

  for character in thrownout:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)

  for character in thrownout2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)

  for character in thrownout4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout7:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout8:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout9:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout10:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout11:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout12:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout13:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  for character in thrownout14:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout15:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout16:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout17:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout18:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout19:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
  for character in thrownout20:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.01)
    sys.exit()

#######################################################################################################
#                                                                                                     #
#                                               module specific challenges                            #
#######################################################################################################

def player_commands(myCommandX):
  playerlocation = str(my_player.location.lower())
  if playerlocation in ['great_hall']:
    
    if myCommandX == ('1'):
      examine_bookshelf()
    elif myCommandX == ('2'):
      examine_curtain()
    elif myCommandX == ('3'):
      fix_clock()

  if playerlocation in ['trophy_room']:
    if myCommandX == ('1'):
      examine_statue()
    elif myCommandX == ('2'):
      investigate_lump()
    elif myCommandX == ('3'):
      tinkling_bells()

  if playerlocation in ['long_hall']:
    if myCommandX == ('1'):
      hear_fortune()
    elif myCommandX == ('2'):
      escape()
    elif myCommandX == ('3'):
      run_from_fortuneteller()

  if playerlocation in ['kitchen']:
    if myCommandX == ('1'):
      hide_from_the_gardener()
    elif myCommandX == ('2'):
      open_wooden_box()
    elif myCommandX == ('3'):
      squish_spider()

#Challenges:\n1.) Examine the painting?\n2.) Turn around quick in case someone is following you?\n3.) Remind yourself there is no such thing as ghosts and goblins?\n',
  if playerlocation in ['stairway']:
    if myCommandX == ('1'):
      examine_painting()
    elif myCommandX == ('2'):
      ivan_turn()
    elif myCommandX == ('3'):
      no_ghosts()

#Challenges:\n1.) Examine the spongy floor?\n2.) Look at the bookcase?\n3.) Jump on the bed?\n',
  if playerlocation in ['small_bedroom']:
    if myCommandX == ('1'):
      examine_floor()
    elif myCommandX == ('2'):
      check_bookcase()
    elif myCommandX == ('3'):
      jump_on_bed()

#Challenges:\n1.) Look out the window?\n2.) Search the household odds and ends?\n3.) Move the mattress?\n',
  if playerlocation in ['big_bedroom']:
    if myCommandX == ('1'):
      look_out_window()
    elif myCommandX == ('2'):
      search_items()
    elif myCommandX == ('3'):
      move_mattress()

#Challenges:\n1.) Read from the book?\n2.) Check the desk for drawers?\n3.) Open one of the other books?\n',
  if playerlocation in ['study']:
    if myCommandX == ('1'):
      read_book()
    elif myCommandX == ('2'):
      search_desk()
    elif myCommandX == ('3'):
      other_books()

#Challenges:\n1.) Dig through the clothes?\n2.) Open the cabinet?\n3.) Sit on the tiny chair?\n',
  if playerlocation in ['cloak_room']:
    if myCommandX == ('1'):
      check_clothes()
    elif myCommandX == ('2'):
      open_cabinets()
    elif myCommandX == ('3'):
      tiny_chair()

#Challenges:\n1.) Wait and listen?\n2.) Look more closely at the carpet?\n3.) ?\n',
  if playerlocation in ['quiet_hall']:
    if myCommandX == ('1'):
      listen()
    elif myCommandX == ('2'):
      examine_carpet()
    elif myCommandX == ('3'):
      rescue_plant()

#Challenges:\n1.) Examine the painting?\n2.) Turn around quick in case someone is following you?\n3.) Remind yourself there is no such thing as ghosts and goblins?\n',
  if playerlocation in ['hidden_stairway']:
    if myCommandX == ('1'):
      examine_painting_1()
    elif myCommandX == ('2'):
      ivan_turn_1()
    elif myCommandX == ('3'):
      no_ghosts_1()

####################TOMB#NAV###################################################

  if playerlocation in ['darkened_stairway']:
    if myCommandX == ('1'):
      turn_back()

  if playerlocation in ['bottom_of_chute']:
    if myCommandX == ('1'):
      guess_answer()
    elif myCommandX == ('2'):
      need_hint()
    elif myCommandX == ('3'):
      new_riddle()

  if playerlocation in ['water_fountain']:
    if myCommandX == ('1'):
      investigate_carvings()
    elif myCommandX == ('2'):
      try_green_key()
    elif myCommandX == ('3'):
      read_note()

  if playerlocation in ['library']:
    if myCommandX == ('1'):
      first_note_page()
    elif myCommandX == ('2'):
      second_note_page()
    elif myCommandX == ('3'):
      third_note_page()

  if playerlocation in ['room_of_faces']:
    if myCommandX == ('1'):
      turn_star()
    elif myCommandX == ('2'):
      try_fourth_key()
    elif myCommandX == ('3'):
      read_the_note()

  if playerlocation in ['faded_tapestries']:
    if myCommandX == ('1'):
      examine_tapestries()
    elif myCommandX == ('2'):
      search_for_escape_route()
    elif myCommandX == ('3'):
      try_green_key()

  if playerlocation in ['singing_crystals']:
    if myCommandX == ('1'):
      first_clue()
    elif myCommandX == ('2'):
      second_clue()
    elif myCommandX == ('3'):
      third_clue()

  if playerlocation in ['stairway_and_candles']:
    if myCommandX == ('1'):
      light_a_candle()
    elif myCommandX == ('2'):
      blow_a_candle_out()
    elif myCommandX == ('3'):
      read_the_note()

  if playerlocation in ['inner_chamber']:
    if myCommandX == ('1'):
      turn_outer_star()

######################GARDEN#NAV################################################
#Challenges:\n1.) Read Tombstone?\n2.) Watch for the Gardener?\n3.) Examine Pile of Stones?\n',
  if playerlocation in ['graveyard']:
    
    if myCommandX == ('1'):
      read_tombstone()
    elif myCommandX == ('2'):
      watch_for_gardener()
    elif myCommandX == ('3'):
      examine_pile_stones()

#Challenges:\n1.) Examine Leaking Hose?\n2.) Try to Fix Broken Bench?\n3.) Examine Flower Pots?\n',
  if playerlocation in ['kitchen_door']:
    
    if myCommandX == ('1'):
      examine_hose()
    elif myCommandX == ('2'):
      fix_bench()
    elif myCommandX == ('3'):
      examine_flowerpots()

#Challenges:\n1.) Examine Broken Lawnmower?\n2.) Search Workbench?\n3.) Examine Gears?\n',
  if playerlocation in ['gardeners_shed']:
    
    if myCommandX == ('1'):
      examine_lawnmower()
    elif myCommandX == ('2'):
      search_workbench()
    elif myCommandX == ('3'):
      examine_gears()

#Challenges:\n1.) Catch a Grasshopper?\n2.) Sneak Around the Gardeners Shed?\n',
  if playerlocation in ['shed_door']:
    
    if myCommandX == ('1'):
      catch_grasshopper()
    elif myCommandX == ('2'):
      sneak_around_shed()

#Challenges:\n1.) Gather Sunflower Seeds?\n2.) Squish Tomatoes?\n',
  if playerlocation in ['vegetable_patch']:
    
    if myCommandX == ('1'):
      gather_sunflower_seeds()
    elif myCommandX == ('2'):
      squish_tomatoes()

#######################################################################################################
#                                                                                                     #
#                                                 necc. specific CMDS                                 #
#######################################################################################################

def challenges(myAction):
  playerlocation = my_player.location
  print('' + zonemap[my_player.location][EXAMINATION] + ' ')
  commandX = input("Choose your path\n1, 2, 3, or go back: ")
  commandXs = [ "1","2","3", "go back" ]
  if commandX not in commandXs:
    print("Unknown, use 1, 2, or 3")
    prompt()
  elif commandX.lower() in ["go back"]:
    prompt()
  else:
    player_commands(commandX.lower()) 

def show():
  playerlocation = my_player.location.lower()

  print("Showing...\n\nThe things you can get: ")
  with open('./Players/' + my_player.name + '/' +  str(playerlocation) + '.txt','r') as show_items:
    lines = show_items.read()
    print(lines)

    prompt()

def player_status(myAction):
  print("Name: " + my_player.name + "")
  print("Health: " + str(my_player.health) + "\n")
  print("You are wearing:\n")
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  garments = file.read()
  print("" + garments + "")
  file.close()

  print("And in your hands you have:")
  file = open('./Players/' + my_player.name + '/holding.txt','r')
  worts = file.read()
  print(worts)
  file.close()
  prompt()

#######################################################################################################
#                                                                                                     #
#                                                      basic commands                                 #
#######################################################################################################

def player_clear(myAction):
  os.system('clear')
  prompt()

def player_move(myAction):
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:
    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:
    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:
    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:
    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:
    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)

#######################################################################################################
#                                                                                                     #                                              
#                                       save game                                                     #
#######################################################################################################

def load_backpack():

  save_room = input("Save your current location?\nYes or No.\n")
  if save_room.lower() in 'no':
    file = open('./Players/' + my_player.name + '/startlocation.txt','w+')

    file.write('Great_Hall')
    file.close()
    save_name()
    
  else:
    file = open('./Players/' + my_player.name + '/startlocation.txt','w+')
    file.write(my_player.location)
    file.close()
    save_name()

def save_name():
  file = open('./Lists/player_card.txt','r')
  players = file.read()
  if my_player.name not in players:
    file.close()
    file = open('./Lists/player_card.txt','a+')
    file.write('' + str(my_player.name) + '\n')
    file.close
    close_all_files()
  else:
    close_all_files()

def close_all_files():
  sys.exit()

#######################################################################################################
#                                                                                                     #                                     delete   
#                                                                                                     #
#######################################################################################################

def end_game():
  playername = my_player.name
  file = open('./Lists/player_card.txt','r')
  players = file.readlines()
  remove_player = open('./Lists/player_card.txt','w+')
  for player in players:
    if player != str(playername):
      remove_player.write(player)
      continue
    continue
  file.close()
  remove_player.close()
  os.system("rm -r ./Players/" + str(playername))
  sys.exit()

#######################################################################################################
#                                                                                                     #
#                                                      prompt                                         #
#######################################################################################################

def prompt():
  print('' + my_player.location.upper() + '\n')
  print('challenges - show more - move - look - options - status - quit')
  global playerlocation
  playerlocation = my_player.location
  global playername
  playername = my_player.name.lower()
  global action
  action = input("Command: ")
  actions = ['quit','look','move','options','status','challenges','show more']
  if action.lower() not in actions:
    print('Command unrecognized.\n')
    prompt()
####################################DOUBLE#CHECK#QUIT##############################################
  elif action.lower() == ("quit"):
    quit_logo = input("Save Game For You?\nYes or No: \n")
    if quit_logo.lower() in ('yes'):
      load_backpack()
    else:
      print("Warning: Any reply other than 'yes' will delete your player completely!!!\n")
      secure_quit = input("Yes to save this player and progress!!!\n")
      if secure_quit.lower() in ('yes'):
        load_backpack()
      else:
        end_game()
###################################################################################################
  elif action.lower() in ['move']:
    player_move(action.lower())
    return
  elif action.lower() in ['look']:
    player_look()
  elif action.lower() in ['options']:
    player_options(action.lower())
    return
  elif action.lower() in ['status']:
    player_status(action.lower())
    return
  elif action.lower() in ['challenges']:
    challenges(action.lower())
  elif action.lower() in ['show more']:
    show()

#######################################################################################################
#                                                                                                     #
#                                                 generate necc txt files                             #
#######################################################################################################

def inventory_stripe(player_name):
  file = open('./Players/' + player_name + '/inventory.txt','w+')
  file.close()

def treasury_stripe(player_name):
  file = open('./Lists/treasuryList.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + player_name + '/treasuryList.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()

def holding_stripe(player_name):
  file = open('./Players/' + player_name + '/holding.txt','w+')
  file.close()

def wearing_stripe(player_name):

  file = open('./Lists/basic_inventory.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + player_name + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
 
def clothing_stripe():
  file = open('./Lists/clothing.txt','r')
  file.close()

def weaponOrTool_stripe():
  file = open('./Lists/weaponOrTool.txt','r')
  file.close()

def treasure_stripe():
  file = open('./Lists/treasure.txt','r')
  file.close()

def player_files(player_name):
  file = open('./Players/' + player_name + '/wearing.txt','r')
  file.close()

def new_holding(player_name):
  file = open('./Players/' + player_name + '/holding.txt','r')
  file.close()

def new_inv(player_name):
  file = open('./Players/' + player_name + '/inventory.txt','r')
  file.close()

def new_treas(player_name):
  file = open('./Players/' + player_name + '/treasuryList.txt','r')
  file.close()

#######################################################################################################
#                                                                                                     #
#                                                 character CRUD                                      #
#######################################################################################################

def append_wear(clothing_c, playerlocation):
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  isWearing = file.read()
  
  if clothing_c in isWearing:
    print("You already are wearing your " + clothing_c + "") 
    file.close()
    prompt()
    
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    items = file.readlines()
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for item in items:
      if item != ('' + str(clothing_c) + '\n'):
        line_write_file.write(item)
        continue
      continue
    file.close()
    line_write_file.close()
    file = open('./Players/' + my_player.name + '/wearing.txt','a+')
    file.write('' + str(clothing_c) + '\n')
    file.close()
    print("You wear your " + clothing_c + '')
    prompt()

def append_WorT(weapon_or_tool_c, playerlocation):
  file = open('./Players/' + my_player.name + '/holding.txt','r')
  isHolding = file.readlines()
  
  length = len(isHolding)
  if weapon_or_tool_c in isHolding:
    print("" + weapon_or_tool_c + " is already in your hands.")
    file.close()
    return
  elif length > 1:
    print("You only have two hands.")
    prompt()
    
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    items = file.readlines()
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for item in items:
      if item != ('' + str(weapon_or_tool_c) + '\n'):
        line_write_file.write(item)
        continue
      continue
    file.close()
    line_write_file.close()
    file = open('./Players/' + my_player.name + '/holding.txt','a+')
    file.write('' + str(weapon_or_tool_c) + '\n')
    file.close()
    print("Your " + weapon_or_tool_c + " is in your hands.")
    prompt()

def take_item(want, playerlocation):
  playerlocation = my_player.location.lower()
  file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
  contents = file.read()
  
  if want in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
    lines = file.readlines()

    next_file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','w')

    for line in lines:
      if line != ('' + str(want) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close()
    
    append_inventory(want, playerlocation)
  else:
    file.close()
    prompt()  
  
def append_inventory(want, playerlocation):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
    location = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','a+')
    file.write(want)
    file.close()
    prompt()   
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(want) + '\n')
    file.close()
    prompt()

def update_room_contents(drop_item, playerlocation):
  file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
  location = file.readlines()
  file.close()
  file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','a+')
  file.write( '' + str(drop_item) + '\n')
  file.close
  prompt()

def drop_wearing(playerlocation, wearing_contents):

  drop_item = input("Choose item: \n")
  if drop_item in wearing_contents:
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    w_lines = file.readlines()
    
    next_file = open('./Players/' + my_player.name + '/wearing.txt','w')

    for w_line in w_lines:
      if w_line != ('' + str(dropr_item) + '\n'):
        next_file.write(w_line)
        continue         
      continue
    
    file.close()
    next_file.close()
    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    prompt()

def drop_holding(playerlocation, holding_contents): 

  drop_item = input("Choose item: \n")
  if drop_item in holding_contents:
    
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    h_lines = file.readlines()
    
    next_file = open('./Players/' + my_player.name + '/holding.txt','w')

    for h_line in h_lines:
      if h_line != ('' + str(drop_item) + '\n'):
        next_file.write(h_line)
        continue
      continue
    
    file.close()
    next_file.close()
    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    prompt()

def drop_backpack(playerlocation, inventory_contents):
  drop_item = input("Choose item: ")

  if drop_item.lower() not in inventory_contents:
    print("You don't have one of those.\n")
    prompt()
        
  elif drop_item.lower() in inventory_contents:

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    d_lines = file.readlines()
      
    next_file = open('./Players/' + my_player.name + '/inventory.txt','w')

    for d_line in d_lines:
      if d_line != ('' + str(drop_item) + '\n'):
        next_file.write(d_line)
        continue
      continue
    file.close()
    next_file.close()

    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    file.close()
    print("What is that?")
    prompt()

def inventory_commands(myDecisionX):
  playerlocation = my_player.location.lower()
  print('\nget - wear - hold - drop - update - go back')
  global inventX
  inventX = input("Inventory Command: ")
  if inventX.lower() not in ['get', 'wear', 'hold', 'drop','update','go back']:
    print("Unknown command. ")
    prompt()
  elif inventX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif inventX.lower() == 'get':
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt', 'r')
    contents = file.read()
    print(contents)
      
    global want
    want = input("What do you want to get: " )
    if want.lower() == ('go back'):
      file.close() 
      os.system('clear')
      prompt()

    elif want.lower() not in contents:
      print("Where do you see that?.\n")
      file.close()
      prompt()

    elif want.lower() in contents:
      file.close()
      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      my_contents = file.read()
        
      if want.lower() in my_contents:
        file.close()
        print("You already have one of these.\n")
        prompt()
      else:
        print("You take the " + want + " from the " + playerlocation.lower() + "")
        file.close()
        take_item(want, playerlocation)
    else:
        print("This " + str (want) + " you want so bad might not exist\n")
        file.close()
        prompt()

  elif inventX.lower() == 'wear':
    playerlocation = my_player.location.lower()
    print('\n')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    contents = file.read()
    print(contents)

    global clothing_c
    clothing_c = input("Choose item: ")
    if clothing_c.lower() == ('go back'):
      file.close()
      os.system('clear')
      prompt()
    elif clothing_c.lower() not in contents:
      print("You don't have one of those.\n")
      file.close()
      prompt()
    else:
      file.close()
      file = open('./Items/clothing.txt','r')
      isGarment = file.read()

      if clothing_c in isGarment:
        file.close()
        append_wear(clothing_c, playerlocation)
          
      else:
        print("That is not something you can wear.")
        file.close()
        prompt()
          
  elif inventX.lower() == 'hold':
    playerlocation = my_player.location.lower()
    print('\n')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    contents = file.read()
    print(contents)
      
    global tool_or_weapon_c
    tool_or_weapon_c = input("Choose item: ")
    if tool_or_weapon_c.lower() == ('go back'):
      file.close()
      os.system('clear')
      prompt()

    elif tool_or_weapon_c.lower() not in contents:
      print("You don't have one of those.\n")
      file.close()
      prompt()
        
    else:
      file.close()
      file = open('./Items/weaponOrTool.txt','r')
      isWorT = file.read()
        
      if tool_or_weapon_c.lower() in isWorT:
        file.close()
        append_WorT(tool_or_weapon_c, playerlocation)
          
      else:
        file.close()
        print("That is not a hand held implement.")
        prompt()

  elif inventX.lower() == 'drop':
    playerlocation = my_player.location.lower()
    print('In your hands:')
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    holding_contents = file.read()
    print(holding_contents)
    file.close()
    print('You are wearing:')
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    wearing_contents = file.read()
    print(wearing_contents)
    file.close()
    print('In your backpack:')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    inventory_contents = file.read()
    print(inventory_contents)
    file.close()
    global drop_item
    choice = input("Select 'backpack', 'holding', or 'wearing': ")
    if choice.lower() == ('backpack'):
      drop_backpack(playerlocation, inventory_contents)
    elif choice.lower() == ('holding'):
      drop_holding(playerlocation, holding_contents)
    elif choice.lower() == ('wearing'):
      drop_wearing(playerlocation, wearing_contents)
    else:
      os.system('clear')
      prompt()

  elif inventX.lower() == 'update':
    os.system('clear')
    print("Updating inventory...\n")
    player_name = my_player.name
    inv_update(player_name)

def inv_update(player_name):

  invs = file.readlines()
  inv_file = open('./Players/' + player_name + '/inventory.txt','w')
  for inv in invs:
    inv_file.write(inv)
    continue
  file.close()
  inv_file.close()
  prompt()

def player_options(myAction):
  os.system('clear')
  print('inventory - inventory commands - go back')
  opt = "Choose an option: "
  global decisionX
  decisionX = input(opt)

  if decisionX.lower() not in ['inventory', 'inventory commands','go back']:
    print("Unknown command. ")
    prompt()
  elif decisionX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif decisionX.lower() == ('inventory'):
    print("You have the following in your inventory...\n")


    with open('./Players/' + my_player.name + '/inventory.txt','r') as inventory_items:
      lines = inventory_items.read()
      print(lines)

      prompt()

  else: 
    decisionX.lower() == ('inventory commands')
    inventory_commands(decisionX)

#######################################################################################################
#                                                                                                     #
#                                                 set up and main                                     #
#######################################################################################################

def main_game_loop():
  while my_player.game_over is False:
    prompt()

def setup_game():

  question = "\nHello, I hope you are ready for a scare. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  player_name = input("Your Name: ")

  my_player.name = player_name

  welcome = "Okay, " + player_name + " let's begin. You need to know a few things.\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.03)

  help = "### Verbs are available and certain language processing. The basic CMDS \n" 
  help1 = "### are: look, get, drop, hold, show more, challenges, and move. You \n"
  help2 = "### have a certain amount of Health, check this with: status, and you \n"
  help3 = "### can only explore The Tomb for a certain amount of time. Use: clock \n"
  help4 = "### to make sure you do not get trapped in The Tomb!\n\n"
  help5 = "### If you do get stuck, you can quit and start again at the beginning. \n"
  help6 = "### And remember it is just a game!\n\n"
  for character in help:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help1:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help3:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)

  goodluck = "\n\n\nOkay, " + player_name + " you will be you and the clock starts ticking now!!!\n"
  for character in goodluck:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.08) # was time.sleep(0.08)
  os.system('clear')
  os.system("mkdir ./Players/" + player_name)
  os.system("cd ./Players/" + player_name)
  os.system("touch __init__.py")
  os.system("cd ..")
  os.system("cp -r ./Rooms/* ./Players/" + player_name)
  inventory_stripe(player_name)
  treasury_stripe(player_name)
  holding_stripe(player_name)
  wearing_stripe(player_name)
  player_files(player_name)
  new_holding(player_name)
  new_inv(player_name)
  new_treas(player_name)
  run_game(player_name)

def run_game(player_name):
  my_player.name = player_name
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()

  bigblackdoor = "\n\n\nTHE BIG BLACK DOOR CREAKS OPEN...\n"
  for character in bigblackdoor:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nGREAT_HALL\nA flurry of bats suddenly flaps through the doorway, their screeching barely \n' +
'audible as they careen past your head. They flap past you into the rooms \n' +
'and halls beyond. The room from which they came seems barren at first glance.\n\n' +
'An old clock stands at the north side of the room between two cobweb covered \n' +
'bookshelves. It clicks loudly. Its winding is too slow and the gears rattle \n' +
'with every passing tick.\n\n' +
'To the East is a Door\n\n' +
'High above the bookshelf is a large round window. It is cloudy with dirt and \n' +
'age. Another window just like it is high up on the east wall just below the \n' +
'carved wooden rafters. On the south wall are dozens of oil paintings, normal \n' +
'haunted house paintings of ancestors of people who are long since gone away \n' +
'posing like royalty wearing kilts beside a fire as dogs roll about at foot. Yet \n' +
'behind you there is no window. You turn and look and sure enough a thick black \n' +
'curtain covers nearly the entire wall. It is only pulled back enough for the \n' +
'door to swing inward.\n\n' +
'The clock rattles again. The poor thing almost seems to be in pain. Maybe you \n' +
'can fix it. The glass door has a handle.\n\n')
  player.location = 'Great_Hall'
  main_game_loop()

title_screen()

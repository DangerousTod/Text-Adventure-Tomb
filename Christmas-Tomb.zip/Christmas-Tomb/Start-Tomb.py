#! /usr/bin/env python3
python3 tomb_main.py
